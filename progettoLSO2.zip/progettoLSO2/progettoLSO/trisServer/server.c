#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUFFER_SIZE 1024
#define MAX_ROOMS 10
#define WAITING 0
#define STARTED 1
#define TERMINATED 2

typedef struct {
    char board[3][3];
    int player_a_sock;
    int player_b_sock;
    char player_a_name[32];
    char player_b_name[32];
    int turn;   
    int status; 
    int pending_b_sock;
    char pending_b_name[32];
    int client_count; 
    pthread_mutex_t mutex;
} GameRoom;

GameRoom stanze[MAX_ROOMS];

int find_room_by_sock(int sock) {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (stanze[i].player_a_sock == sock || 
            stanze[i].player_b_sock == sock || 
            stanze[i].pending_b_sock == sock) {
            return i;
        }
    }
    return -1;
}

void handle_sigint(int sig) {
    printf("\n[SERVER] Spegnimento in corso...\n");
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (stanze[i].player_a_sock != -1) close(stanze[i].player_a_sock);
        if (stanze[i].player_b_sock != -1) close(stanze[i].player_b_sock);
        pthread_mutex_destroy(&stanze[i].mutex);
    }
    exit(0);
}

int check_winner(char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        if (board[i][0] != '_' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) return (board[i][0] == 'X') ? 1 : 2;
        if (board[0][i] != '_' && board[0][i] == board[1][i] && board[1][i] == board[2][i]) return (board[0][i] == 'X') ? 1 : 2;
    }
    if (board[1][1] != '_') {
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) return (board[1][1] == 'X') ? 1 : 2;
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0]) return (board[1][1] == 'X') ? 1 : 2;
    }
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == '_') return 0;
    return 3; 
}

void broadcast_board(GameRoom *room) {
    char msg[512]; 
    char* nameA = (strlen(room->player_a_name) > 0) ? room->player_a_name : "PlayerX";
    char* nameB = (room->player_b_sock != -1) ? ((strlen(room->player_b_name) > 0) ? room->player_b_name : "PlayerO") : "ATTESA";

    snprintf(msg, sizeof(msg), "BOARD %c%c%c%c%c%c%c%c%c NEXT %d NAMES %s %s\n", 
            room->board[0][0], room->board[0][1], room->board[0][2],
            room->board[1][0], room->board[1][1], room->board[1][2],
            room->board[2][0], room->board[2][1], room->board[2][2],
            room->turn, nameA, nameB);
            
    if (room->player_a_sock != -1) send(room->player_a_sock, msg, strlen(msg), 0);
    if (room->player_b_sock != -1) send(room->player_b_sock, msg, strlen(msg), 0);
}

void *handle_client(void *arg) {
    pthread_detach(pthread_self());
    
    int sock = *(int*)arg;
    free(arg);
    char buffer[BUFFER_SIZE];
    int valread;

    while ((valread = recv(sock, buffer, BUFFER_SIZE - 1, 0)) > 0) {
        buffer[valread] = '\0';
        char *saveptr;
        char *line = strtok_r(buffer, "\r\n", &saveptr);
        
        while (line != NULL) {
            
            if (strncmp(line, "LIST", 4) == 0) {
                for (int i = 0; i < MAX_ROOMS; i++) {
                    pthread_mutex_lock(&stanze[i].mutex);
                    if (stanze[i].player_a_sock != -1 && stanze[i].status != TERMINATED) {
                        char msg[64];
                        
                        if (stanze[i].client_count == 2 || stanze[i].pending_b_sock != -1) {
                            snprintf(msg, sizeof(msg), "FULL_ROOM %s\n", stanze[i].player_a_name);
                        } else {
                            snprintf(msg, sizeof(msg), "AVAILABLE %s\n", stanze[i].player_a_name);
                        }
                        send(sock, msg, strlen(msg), 0);
                    }
                    pthread_mutex_unlock(&stanze[i].mutex);
                }
            }
            else if (strncmp(line, "CREATE", 6) == 0) {
                for (int i = 0; i < MAX_ROOMS; i++) {
                    pthread_mutex_lock(&stanze[i].mutex);
                    if (stanze[i].player_a_sock == -1 && stanze[i].player_b_sock == -1) {
                        stanze[i].player_a_sock = sock;
                        stanze[i].client_count = 1;
                        send(sock, "WELCOME 0\n", 10, 0);
                        printf("[SERVER] Socket %d ha creato la stanza %d.\n", sock, i);
                        pthread_mutex_unlock(&stanze[i].mutex);
                        break;
                    }
                    pthread_mutex_unlock(&stanze[i].mutex);
                }
            }
            else if (strncmp(line, "JOIN_REQ ", 9) == 0) {
                char target_creator[32], my_name[32];
                if (sscanf(line, "JOIN_REQ %31s %31s", target_creator, my_name) == 2) {
                    int joined = 0;
                    for (int i = 0; i < MAX_ROOMS; i++) {
                        pthread_mutex_lock(&stanze[i].mutex);
                        if (stanze[i].client_count == 1 && strcmp(stanze[i].player_a_name, target_creator) == 0 && stanze[i].pending_b_sock == -1) {
                            stanze[i].pending_b_sock = sock;
                            strncpy(stanze[i].pending_b_name, my_name, 31);
                            
                            char msg[64];
                            snprintf(msg, sizeof(msg), "JOIN_REQUEST %s\n", my_name);
                            send(stanze[i].player_a_sock, msg, strlen(msg), 0);
                            joined = 1;
                            pthread_mutex_unlock(&stanze[i].mutex);
                            break;
                        }
                        pthread_mutex_unlock(&stanze[i].mutex);
                    }
                    if (!joined) {
                        send(sock, "FULL\n", 5, 0);
                    }
                }
            }
            
            int r_idx = find_room_by_sock(sock);
            if (r_idx != -1) {
                GameRoom *room = &stanze[r_idx];
                pthread_mutex_lock(&room->mutex);

                if (strncmp(line, "USER", 4) == 0) {
                    if (sock == room->player_a_sock) sscanf(line, "USER %s", room->player_a_name);
                    else if (sock == room->player_b_sock) sscanf(line, "USER %s", room->player_b_name);
                    broadcast_board(room); 
                }
                else if (strncmp(line, "ACCEPT_JOIN", 11) == 0) {
                    if (sock == room->player_a_sock && room->pending_b_sock != -1) {
                        room->player_b_sock = room->pending_b_sock;
                        strcpy(room->player_b_name, room->pending_b_name);
                        room->client_count = 2;
                        room->status = STARTED;
                        room->pending_b_sock = -1;
                        send(room->player_b_sock, "WELCOME 1\n", 10, 0);
                        broadcast_board(room);
                    }
                }
                else if (strncmp(line, "DECLINE_JOIN", 12) == 0) {
                    if (sock == room->player_a_sock && room->pending_b_sock != -1) {
                        char msg_dec[64];
                        snprintf(msg_dec, sizeof(msg_dec), "JOIN_DECLINED %s\n", room->player_a_name);
                        send(room->pending_b_sock, msg_dec, strlen(msg_dec), 0);
                        room->pending_b_sock = -1; 
                    }
                }
                else if (strncmp(line, "MOVE", 4) == 0) {
                    int r, c;
                    if (sscanf(line, "MOVE %d %d", &r, &c) == 2) {
                        int is_a = (sock == room->player_a_sock);
                        int my_turn = (is_a) ? 0 : 1;
                        if (room->status == STARTED && room->turn == my_turn && r >= 0 && r < 3 && c >= 0 && c < 3 && room->board[r][c] == '_') {
                            room->board[r][c] = (is_a) ? 'X' : 'O';
                            int res = check_winner(room->board);
                            if (res == 0) { 
                                room->turn = (room->turn == 0) ? 1 : 0;
                                broadcast_board(room);
                            } else { 
                                broadcast_board(room);
                                room->status = TERMINATED;
                                if(res == 1) { 
                                    send(room->player_a_sock, "VICTORY\n", 8, 0);
                                    send(room->player_b_sock, "DEFEAT\n", 7, 0);
                                } else if(res == 2) { 
                                    send(room->player_a_sock, "DEFEAT\n", 7, 0);
                                    send(room->player_b_sock, "VICTORY\n", 8, 0);
                                } else { 
                                    send(room->player_a_sock, "DRAW\n", 5, 0);
                                    send(room->player_b_sock, "DRAW\n", 5, 0);
                                }
                            }
                        } else broadcast_board(room);
                    }
                }
                else if (strncmp(line, "REMATCH", 7) == 0) {
                    memset(room->board, '_', sizeof(room->board));
                    room->status = (room->client_count == 2) ? STARTED : WAITING;
                    room->turn = 0;
                    broadcast_board(room);
                }
                else if (strncmp(line, "LEAVE", 5) == 0) {
                    int avv_sock = (sock == room->player_a_sock) ? room->player_b_sock : room->player_a_sock;
                    char* chi_abbandona = (sock == room->player_a_sock) ? room->player_a_name : room->player_b_name;
                    if (avv_sock != -1) {
                        char msg_leave[64];
                        snprintf(msg_leave, sizeof(msg_leave), "OPPONENT_LEFT %s\n", chi_abbandona);
                        send(avv_sock, msg_leave, strlen(msg_leave), 0);
                    }
                    memset(room->board, '_', sizeof(room->board));
                    if (room->status == STARTED) {
                        room->status = WAITING;
                    }

                    if (sock == room->player_a_sock) {
                        room->player_a_sock = -1;
                        memset(room->player_a_name, 0, 32);
                        if (room->player_b_sock != -1) { // PROMOZIONE
                            room->player_a_sock = room->player_b_sock;
                            strcpy(room->player_a_name, room->player_b_name);
                            room->player_b_sock = -1;
                            memset(room->player_b_name, 0, 32);
                            usleep(50000); 
                            send(room->player_a_sock, "WELCOME 0\n", 10, 0);
                        }
                    } else {
                        room->player_b_sock = -1;
                        memset(room->player_b_name, 0, 32);
                    }
                    
                    room->client_count--;
                    if (room->client_count <= 0) {
                        room->client_count = 0;
                        room->status = WAITING;
                        room->turn = 0;
                        room->pending_b_sock = -1;
                    }
                    usleep(50000);
                    broadcast_board(room); 
                }
                pthread_mutex_unlock(&room->mutex);
            }
            line = strtok_r(NULL, "\r\n", &saveptr);
        }
    }

    int r_idx = find_room_by_sock(sock);
    if (r_idx != -1) {
        GameRoom *room = &stanze[r_idx];
        pthread_mutex_lock(&room->mutex);
        
        int was_in_game = 0;
        int avv_sock = -1;

        if (sock == room->player_a_sock) {
            avv_sock = room->player_b_sock;
            room->player_a_sock = -1;
            memset(room->player_a_name, 0, 32);
            was_in_game = 1;
        } else if (sock == room->player_b_sock) {
            avv_sock = room->player_a_sock;
            room->player_b_sock = -1;
            memset(room->player_b_name, 0, 32);
            was_in_game = 1;
        } else if (sock == room->pending_b_sock) {
            room->pending_b_sock = -1;
            memset(room->pending_b_name, 0, 32);
        }
        
        if (was_in_game) {
            room->client_count--;
        if (avv_sock != -1 && room->status == STARTED) {
            char msg_leave[64];
            char* chi_abbandona = (avv_sock == room->player_b_sock) ? room->player_a_name : room->player_b_name;
            snprintf(msg_leave, sizeof(msg_leave), "OPPONENT_LEFT %s\n", chi_abbandona);
            send(avv_sock, msg_leave, strlen(msg_leave), 0);
        }
            if (room->client_count <= 0) {
                room->client_count = 0;
                memset(room->board, '_', sizeof(room->board));
                room->status = WAITING;
                room->turn = 0;
                room->pending_b_sock = -1;
            }
        }
        pthread_mutex_unlock(&room->mutex);
    }

    printf("[SERVER] Client su socket %d disconnesso.\n", sock);
    close(sock);
    return NULL;
}


int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    signal(SIGINT, handle_sigint);

    for (int i = 0; i < MAX_ROOMS; i++) {
        memset(stanze[i].board, '_', sizeof(stanze[i].board));
        stanze[i].turn = 0;
        stanze[i].status = WAITING;
        stanze[i].player_a_sock = -1;
        stanze[i].player_b_sock = -1;
        stanze[i].pending_b_sock = -1;
        stanze[i].client_count = 0;
        memset(stanze[i].player_a_name, 0, 32);
        memset(stanze[i].player_b_name, 0, 32);
        memset(stanze[i].pending_b_name, 0, 32);
        pthread_mutex_init(&stanze[i].mutex, NULL);
    }

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(8080);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 10); 

    printf("[SERVER] In ascolto sulla porta 8080. Multi-Stanza Attivato!\n");

    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        pthread_t tid;
        int *p_sock = malloc(sizeof(int));
        *p_sock = new_socket;
        pthread_create(&tid, NULL, handle_client, p_sock);
    }
    return 0;
}
