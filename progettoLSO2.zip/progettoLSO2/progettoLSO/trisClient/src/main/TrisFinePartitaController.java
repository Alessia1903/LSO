import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisFinePartitaController {

    @FXML
    public void tornaAllaHome(ActionEvent event) {
        // Chiude il popup e torna alla home
        chiudiPopupEVaiHome(event);
    }

    @FXML
    public void giocaAncora(ActionEvent event) {
        // Chiudiamo SOLO il popup
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();

        GameClient client = TrisLoginController.getClient();
        if (client != null) {
            // Diciamo al gioco che stiamo aspettando una rivincita (evita il popup di abbandono)
            if (client.getGameController() != null) {
                client.getGameController().setInRivincita(true);
                client.getGameController().impostaAttesaAvversario();
            }
            // Invia la richiesta di rivincita al server
            client.inviaComando("REMATCH");
        }
    }

    private void chiudiPopupEVaiHome(ActionEvent event) {
        try {
            // 1. Diciamo al server che stiamo lasciando la stanza per liberarla
            if (TrisLoginController.getClient() != null) {
                TrisLoginController.getClient().inviaComando("LEAVE");
            }

            // 2. Chiudiamo la finestrella del popup
            Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            popupStage.close();

            // 3. Rimettiamo la Home nella finestra principale
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Tris_home.fxml"));
            Parent root = loader.load();

            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                mainStage.setScene(new Scene(root));
                mainStage.setTitle("Tris - Home");
                mainStage.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}