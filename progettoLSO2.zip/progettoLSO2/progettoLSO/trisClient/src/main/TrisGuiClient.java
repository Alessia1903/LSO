import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TrisGuiClient extends Application {


    @Override
    public void start(Stage primaryStage) {
        try {
            // Carica il file FXML [cite: 1, 3]
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Tris_username.fxml"));
            
            Parent root = loader.load();
            // Crea la scena con le dimensioni definite nel FXML (300x200) 
            Scene scene = new Scene(root);
            TrisLoginController.setPrimaryStage(primaryStage);
            primaryStage.setTitle("Tris - Login");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false); // Opzionale: impedisce il ridimensionamento
            primaryStage.show();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Errore nel caricamento del file FXML. Verifica il percorso.");
        }
    }

    public static void main(String[] args) {
        launch(args);
  
    }
}