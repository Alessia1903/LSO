import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.application.Platform;

public class TrisAbbandonatoController {

    @FXML
    public void okCliccato(ActionEvent event) {
        // 1. Chiudiamo solo la finestrella del popup
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();

        // 2. Diciamo alla scacchiera di rimettersi in attesa (non torniamo alla Home!)
        GameClient client = TrisLoginController.getClient();
        if (client != null && client.getGameController() != null) {
            Platform.runLater(() -> {
                client.getGameController().impostaAttesaAvversario();
            });
        }
    }
}