import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisAbbandonatoController {
    
    // Metodo che deve essere chiamato quando clicchi "OK" nel popup
    @FXML
    public void tornaAllaHome(ActionEvent event) {
        try {
            // 1. Chiude SOLO la finestrella del popup
            Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            popupStage.close();

            // 2. Carica il file della Home
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_home.fxml"));
            Parent root = loader.load();

            // 3. Applica la Home alla finestra PRINCIPALE (quella del gioco)
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                mainStage.setScene(new Scene(root));
                mainStage.setTitle("Tris - Home");
                mainStage.show();
            } else {
                System.err.println("Errore: Impossibile trovare la finestra principale!");
            }
        } catch (Exception e) {
            System.err.println("Errore nel caricamento della Home dal popup!");
            e.printStackTrace();
        }
    }
}