import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.application.Platform;

public class TrisAbbandonatoController {

    @FXML private Label messaggioLabel;

    public void setMessaggio(String nomeAvversario) {
        if (messaggioLabel != null) {
            messaggioLabel.setText("Oh no! " + nomeAvversario + " ha abbandonato la partita improvvisamente!");
        }
    }

    @FXML
    public void okCliccato(ActionEvent event) {
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();

        GameClient client = TrisLoginController.getClient();
        if (client != null && client.getGameController() != null) {
            Platform.runLater(() -> {
                client.getGameController().impostaAttesaAvversario();
            });
        }
    }
}