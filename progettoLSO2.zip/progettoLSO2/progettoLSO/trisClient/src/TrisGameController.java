import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;

import javafx.application.Platform;

public class TrisGameController {
    @FXML private GridPane gridPane; 
    @FXML private Label statusLabel; // Aggiungi questa Label nel tuo FXML per i messaggi
    @FXML private Label labelTurno;
    @FXML private Label labelAvversario;

    private String ultimaGriglia = "_________";
    
    private GameClient client;
    private Button[][] buttons = new Button[3][3]; // Matrice per gestire i bottoni

    private boolean partitaTerminata = false;
    private boolean inRivincita = false;

    public boolean isPartitaTerminata() { return partitaTerminata; }
    public boolean isInRivincita() { return inRivincita; }
    public void setInRivincita(boolean val) { this.inRivincita = val; }

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
        
        if (this.client != null) {
            this.client.setController(this); 
            System.out.println("Sincronizzato con il server sulla scacchiera.");
            if (TrisHomeController.stoCreandoPartita) {
                this.client.inviaComando("CREATE"); // Crea una stanza
                this.client.sendUsername(TrisLoginController.getUsername());
            } else {
                this.client.inviaComando("JOIN_REQ " + TrisLoginController.getUsername());
                if (statusLabel != null) statusLabel.setText("In attesa dell'approvazione...");           
            }   
                this.client.sendUsername(TrisLoginController.getUsername());
        }

        // Mappa i bottoni del GridPane nella nostra matrice 3x3
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Integer r = GridPane.getRowIndex(node);
                Integer c = GridPane.getColumnIndex(node);
                // Gestione indici null (default a 0)
                int row = (r == null) ? 0 : r;
                int col = (c == null) ? 0 : c;
                buttons[row][col] = (Button) node;
            }
        }
    }

   // Unico metodo per gestire i messaggi dal GameClient
    public void gestisciMessaggioServer(String messaggio) {
        // Usiamo Platform.runLater per essere sicuri di toccare la UI nel thread giusto
        Platform.runLater(() -> {
            try {
                if (messaggio.startsWith("BOARD")) {
                    aggiornaScacchiera(messaggio);
                } else if (messaggio.startsWith("VICTORY")) {
                    System.out.println("[DEBUG] Elaborazione Vittoria in corso...");
                    if (statusLabel != null) statusLabel.setText("HAI VINTO! 🎉");
                    if (gridPane != null) gridPane.setDisable(true);
                    
                    mostraPopupRisultato("/fxml/Tris_vittoria.fxml");
                    
                } else if (messaggio.startsWith("DEFEAT")) {
                    System.out.println("[DEBUG] Elaborazione Sconfitta in corso...");
                    if (statusLabel != null) statusLabel.setText("HAI PERSO! 😢");
                    if (gridPane != null) gridPane.setDisable(true);
                    
                    mostraPopupRisultato("/fxml/Tris_sconfitta.fxml");
                    
                } else if (messaggio.startsWith("DRAW")) {
                    System.out.println("[DEBUG] Elaborazione Pareggio in corso...");
                    if (statusLabel != null) statusLabel.setText("PAREGGIO! 🤝");
                    if (gridPane != null) gridPane.setDisable(true);
                    
                    mostraPopupRisultato("/fxml/Tris_pareggio.fxml");
                }
            } catch (Exception e) {
                System.err.println("[ERRORE GRAVE] Crash durante la gestione del messaggio: " + messaggio);
                e.printStackTrace(); // Questo stamperà l'errore esatto se c'è un problema!
            }
        });
    }

    // Metodo per mostrare i popup centrati
    private void mostraPopupRisultato(String nomeFileFxml) {
        try {
            System.out.println("[DEBUG] Tento di caricare il popup: " + nomeFileFxml);
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nomeFileFxml));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL); // Blocca la finestra dietro
            
            // Centra il popup sopra la finestra principale
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                popupStage.initOwner(mainStage); 
            }
            
            popupStage.setTitle("Fine Partita");
            popupStage.setScene(new Scene(root));
            popupStage.show();
            System.out.println("[DEBUG] Popup aperto con successo!");
            
        } catch (Exception e) {
            System.err.println("[ERRORE] Impossibile caricare il popup: " + nomeFileFxml);
            e.printStackTrace();
        }
    }

    private void aggiornaScacchiera(String messaggio) {
    // Dividiamo il messaggio: "BOARD X________ NEXT 1 NAMES Pippo ATTESA"
    String[] parti = messaggio.split(" ");
    
    // Controllo minimo: il messaggio deve avere almeno BOARD, GRIGLIA, NEXT, NUMERO
    if (parti.length < 4) {
        System.err.println("Messaggio del server troppo corto: " + messaggio);
        return;
    }

    String datiGriglia = parti[1];      // "X________"
    this.ultimaGriglia = datiGriglia;
    int turnoDi = Integer.parseInt(parti[3]); // 0 o 1
    int mioID = client.getPlayerID();
    System.out.println("[DEBUG GIOCO] Ricevuta scacchiera. Mio ID: " + mioID + " | Turno di: " + turnoDi);

    // Ripristina lo stato interno per permettere di giocare
    this.partitaTerminata = false;
    this.inRivincita = false;
    // --- 1. GESTIONE NOMI E STATO AVVERSARIO ---
    // Verifichiamo se il server ha inviato anche i nomi (parti[5] e parti[6])
    if (parti.length >= 7 && parti[4].equalsIgnoreCase("NAMES")) {
        String nomeP1 = parti[5];
        String nomeP2 = parti[6];

        String mioNome = TrisLoginController.getUsername();

        if (nomeP2.equalsIgnoreCase("ATTESA")) {
            if (labelAvversario != null) labelAvversario.setText("In attesa di un avversario...");
            if (labelTurno != null) labelTurno.setText("Stai aspettando lo sfidante...");
            if (gridPane != null) gridPane.setDisable(true); // Blocco forzato
            aggiornaGraficaBottoni(datiGriglia);
            return; // Esci, non serve controllare il turno se manca l'avversario
        } else {
            String nomeAvversario = nomeP1.equalsIgnoreCase(mioNome) ? nomeP2 : nomeP1;
            if (labelAvversario != null) labelAvversario.setText("Partita contro: " + nomeAvversario);        
        }
    }

    // --- 2. AGGIORNAMENTO GRAFICO BOTTONI ---
    aggiornaGraficaBottoni(datiGriglia);

    // --- 3. GESTIONE TURNO ---
    if (mioID != turnoDi) {
        if (labelTurno != null) labelTurno.setText("Attesa turno avversario...");
        if (gridPane != null) gridPane.setDisable(true); // Blocca i click
        System.out.println("[DEBUG GIOCO] Scacchiera BLOCCATA (non è il mio turno).");
    } else {
        String mioSimbolo = (mioID == 0) ? "X" : "O";
        labelTurno.setText("Tocca a te! (" + mioSimbolo + ")");
        if (labelTurno != null) labelTurno.setText("Tocca a te! (" + mioSimbolo + ")");
        
        // SBLOCCO FORZATO: Diciamo a JavaFX di riattivare la griglia in modo assoluto
        if (gridPane != null) {
            gridPane.setDisable(false);
            System.out.println("[DEBUG GIOCO] Scacchiera SBLOCCATA con successo!");
        }
    }
}

// Metodo di supporto per pulire il codice
private void aggiornaGraficaBottoni(String datiGriglia) {
    for (int i = 0; i < 9; i++) {
        int row = i / 3;
        int col = i % 3;
        char simbolo = datiGriglia.charAt(i);
        
        // Imposta il testo del bottone (X, O o vuoto)
        if (buttons[row][col] != null) {
            String testo = (simbolo == '_') ? "" : String.valueOf(simbolo);
            buttons[row][col].setText(testo);
        }
    }
}

    @FXML
    private void handleMossa(ActionEvent event) {
        Button btn = (Button) event.getSource();
        Integer r = GridPane.getRowIndex(btn);
        Integer c = GridPane.getColumnIndex(btn);
        
        client.sendMove(r == null ? 0 : r, c == null ? 0 : c);
    }

    @FXML
    private void handleAbbandona(ActionEvent event) {
        if (client != null) {
            client.inviaComando("LEAVE"); // Invia "LEAVE\n" al server
        }
        tornaAllaHome(event);
    }

    private void tornaAllaHome(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/Tris_home.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void impostaAttesaAvversario() {
        if (statusLabel != null) statusLabel.setText("In attesa di un nuovo sfidante...");
        if (labelTurno != null) labelTurno.setText("");
        if (labelAvversario != null) labelAvversario.setText("Ora sei il proprietario della stanza!");
        if (gridPane != null) gridPane.setDisable(true);
        
        // Svuota i bottoni visivamente
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j] != null) buttons[i][j].setText("");
            }
        }
    }
    public boolean isScacchieraVuota() {
        return "_________".equals(ultimaGriglia);
    }
    public void mostraPopupRichiesta(String nomeRichiedente) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_joinRequest.fxml"));
            Parent root = loader.load();

            TrisJoinRequestController controller = loader.getController();
            controller.setMessaggio(nomeRichiedente); // Inserisce il nome nell'etichetta!

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Richiesta di partecipazione");
            popupStage.setScene(new Scene(root));
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void mostraPopupRifiuto() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_rifiuto.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Richiesta Rifiutata");
            popupStage.setScene(new Scene(root));
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }
}