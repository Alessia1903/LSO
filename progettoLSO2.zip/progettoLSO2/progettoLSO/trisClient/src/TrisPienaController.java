import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisPienaController {
    @FXML public void tornaAllaHome(ActionEvent event) {
        try {
            // Chiudi il popup
            Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            popupStage.close();

            // Torna alla Home
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_home.fxml"));
            Parent root = loader.load();
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                mainStage.setScene(new Scene(root));
                mainStage.setTitle("Tris - Home");
                mainStage.setResizable(false);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
