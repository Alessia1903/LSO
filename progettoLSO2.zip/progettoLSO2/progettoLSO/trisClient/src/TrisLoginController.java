import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class TrisLoginController {

    @FXML private TextField usernameField;
    @FXML private Label labelConnessione;

    public static String username;

    // Connessione condivisa
    private static GameClient sharedClient;
    private static Stage primaryStage;

    @FXML
    public void initialize() {
        // LA MAGIA DEL LOGOUT: 
        // Ogni volta che si apre la schermata di login (sia all'avvio che dopo un logout),
        // creiamo forzatamente un nuovo client e una nuova connessione pulita col Server C.
        try {
            sharedClient = new GameClient(null);
            sharedClient.connect();
            labelConnessione.setText("● Server Online");
            labelConnessione.setTextFill(Color.GREEN);
            System.out.println("[CLIENT] Connesso al server (Nuova connessione).");
        } catch (IOException e) {
            sharedClient = null; // Resettiamo se fallisce
            labelConnessione.setText("● Server Offline (Docker non risponde)");
            labelConnessione.setTextFill(Color.RED);
            System.err.println("[ERRORE] Impossibile connettersi.");
        }
    }

    @FXML
    private void handleLogin(ActionEvent event) {
        if (sharedClient == null) {
            labelConnessione.setText("⚠️ Impossibile accedere: server offline!");
            return;
        }

        username = usernameField.getText();

        // 1. Controlliamo se il nome è vuoto
        if (username == null || username.trim().isEmpty()) {
            System.out.println("Username vuoto!");
            // Ci fermiamo qui senza fare danni, non inviamo nulla al server!
            return;
        }

        // 2. SE IL NOME E' VALIDO, LO INVIAMO AL SERVER! (Bug corretto)
        System.out.println("Utente pronto: " + username);
        sharedClient.sendUsername(username);

        // 3. Andiamo alla Home
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_home.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tris Online - " + username);
            stage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static GameClient getClient() {
        return sharedClient;
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        System.exit(0);
    }

    public static String getUsername(){
        return username;
    }

    // Metodo per impostare lo stage (chiamato nel metodo start di TrisGuiClient)
    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }
    
}