import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

public class TrisHomeController {

    @FXML private ListView<String> listaPartite;
    @FXML private Label nopartite;
    private GameClient client;

    public static boolean stoCreandoPartita = false;

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
    
    if (this.client != null) {
        // Opzione A: Refresh manuale simulato
        
        this.client.setHomeListener(this); 
            nopartite.setVisible(true);
            
            // Appena apro la home, CHIEDO la lista vera al server (non me la invento!)
            this.client.inviaComando("LIST"); 
    }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        // Puliamo la lista
        if (client != null) {
            client.inviaComando("LIST");
        }
    }


    @FXML
    private void handleNewGame(ActionEvent event) {
        // L'utente vuole CREARE una stanza nuova
        stoCreandoPartita = true;
        cambiaScena(event);
    }

    @FXML
    private void handleJoinGame(MouseEvent event) {
        // L'utente vuole UNIRSI a una stanza esistente
        if (event.getClickCount() == 2 && !listaPartite.getSelectionModel().isEmpty()) {
            stoCreandoPartita = false;
            cambiaScena(event);
        }
    }

    private void cambiaScena(Object event) {
        try {
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_game.fxml"));
            Parent root = loader.load();

            Stage stage;
            if (event instanceof ActionEvent) {
                stage = (Stage) ((Node) ((ActionEvent) event).getSource()).getScene().getWindow();
            } else {
                stage = (Stage) ((Node) ((MouseEvent) event).getSource()).getScene().getWindow();
            }

            stage.setScene(new Scene(root));
            stage.setTitle("Tris - In Partita");
            stage.show();
        } catch (Exception e) {
            System.err.println("Errore nel caricamento della scacchiera!");
            e.printStackTrace();
        }
    }
    public void aggiornaListaPartite(boolean disponibile, String nomeCreatore) {
    Platform.runLater(() -> {
        listaPartite.getItems().clear();
        if (disponibile) {
            listaPartite.getItems().add("Partita creata da: " + nomeCreatore);
            nopartite.setVisible(false);
        } else {
            nopartite.setVisible(true);
        }
    });
    }
}
