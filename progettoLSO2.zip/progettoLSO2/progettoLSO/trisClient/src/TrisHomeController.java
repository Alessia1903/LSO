import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

public class TrisHomeController {

    @FXML private ListView<String> listaPartite;
    @FXML private Label nopartite;
    private GameClient client;

    public static boolean stoCreandoPartita = false;
    public static String nomeStanzaDaUnirsi = ""; 

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
        if (this.client != null) {
            this.client.setHomeListener(this); 
            richiediLista();
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        richiediLista();
    }

    private void richiediLista() {
        if (client != null) {
            listaPartite.getItems().clear();
            nopartite.setVisible(true); 
            client.inviaComando("LIST");
        }
    }

    @FXML
    private void handleNewGame(ActionEvent event) {
        stoCreandoPartita = true;
        cambiaScena(event);
    }
    @FXML
    private void handleJoinGame(MouseEvent event) {
        if (event.getClickCount() == 2 && !listaPartite.getSelectionModel().isEmpty()) {
            String selezionata = listaPartite.getSelectionModel().getSelectedItem();
            
            if (selezionata.endsWith("(PIENA)")) {
                mostraPopupPiena();
                return;
            }

            stoCreandoPartita = false;
            nomeStanzaDaUnirsi = selezionata.replace("Partita creata da: ", "").trim();
            cambiaScena(event);
        }
    }

    private void cambiaScena(Object event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_game.fxml"));
            Parent root = loader.load();
            Stage stage;
            if (event instanceof ActionEvent) {
                stage = (Stage) ((Node) ((ActionEvent) event).getSource()).getScene().getWindow();
            } else {
                stage = (Stage) ((Node) ((MouseEvent) event).getSource()).getScene().getWindow();
            }
            stage.setScene(new Scene(root));
            stage.setTitle("Tris In Partita - " + TrisLoginController.getUsername());
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void aggiornaListaPartite(boolean disponibile, String nomeCreatore, boolean isFull) {
        Platform.runLater(() -> {
            if (disponibile) {
                String testo = "Partita creata da: " + nomeCreatore;
                if (isFull) {
                    testo += " (PIENA)";
                }
                listaPartite.getItems().add(testo);
                nopartite.setVisible(false);
            }
        });
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            if (this.client != null) this.client.disconnect();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_username.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tris - Login");
            stage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void mostraPopupPiena() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_piena.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Partita Piena - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();
            popupStage.setOnCloseRequest(event -> event.consume());
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }
}