import java.io.*;
import java.net.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GameClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    
    // Riferimenti ai controller per aggiornare l'interfaccia
    private TrisGameController gameController;
    private TrisHomeController homeController;
    private int playerID = -1; 

    public GameClient(TrisGameController controller) {
        this.gameController = controller;
    }

    public void connect() throws IOException {
        // Connessione al server Docker
        this.socket = new Socket("localhost", 8080);
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        // Unico thread di ascolto per tutta la durata dell'app
        Thread listenerThread = new Thread(this::listenToServer);
        listenerThread.setDaemon(true); 
        listenerThread.start();
    }

    // Metodi per cambiare il "destinatario" dei messaggi del server
    public void setController(TrisGameController controller) {
        this.gameController = controller;
        this.homeController = null; // Quando giochiamo, non siamo più nella home
    }

    public void setHomeListener(TrisHomeController home) {
        this.homeController = home;
        this.gameController = null; // Quando siamo in home, non siamo in gioco
    }

    public void sendMove(int r, int c) {
        if (out != null) out.println("MOVE " + r + " " + c);
    }

    public void richiediListaPartite() {
        if (out != null) out.println("LIST"); 
    }

    private void listenToServer() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println("[SERVER RAW]: " + line);
                final String msg = line.trim();

                // 1. Gestione ID Giocatore (WELCOME 0 o 1)
                if (msg.startsWith("WELCOME")) {
                    this.playerID = Integer.parseInt(msg.split(" ")[1]);
                    System.out.println("Assegnato PlayerID: " + playerID);
                }
                
                else if (msg.equals("OPPONENT_LEFT")) {
                    System.out.println("[DEBUG] Ricevuto OPPONENT_LEFT!");
                    if (gameController != null) {
                        
                        // LA MAGIA: Se la partita era già finita (uno ha vinto) 
                        // OPPURE la scacchiera è intonsa (cioè abbiamo cliccato Gioca Ancora)
                        if (gameController.isPartitaTerminata() || gameController.isScacchieraVuota()) {
                            
                            System.out.println("[DEBUG] L'avversario è uscito, ma eravamo in lobby/fine partita. Attesa silenziosa.");
                            Platform.runLater(() -> gameController.impostaAttesaAvversario());
                            
                        } else {
                            // Abbandono improvviso a metà di una partita vera -> Mostra il popup
                            mostraPopupAbbandono();
                        }
                    }
                }else if (msg.startsWith("JOIN_REQUEST")) {
                // Estrapoliamo il nome: "JOIN_REQUEST Marco" -> "Marco"
                    String nomeRichiedente = msg.substring(13).trim();
                    if (gameController != null) {
                        Platform.runLater(() -> gameController.mostraPopupRichiesta(nomeRichiedente));
                    }
                }
                else if (msg.equals("JOIN_DECLINED")) {
                    if (gameController != null) {
                        Platform.runLater(() -> gameController.mostraPopupRifiuto());
                    }
                }
                
                
                // 2. Gestione Messaggi per la HOME (Lista Partite)
                else if (msg.startsWith("AVAILABLE") || msg.equals("EMPTY")) {
                    if (homeController != null) {
                        if (msg.startsWith("AVAILABLE")){
                    // Il server manderà "AVAILABLE Pippo"
                            String[] parti = msg.split(" ");
                            String nomeCreatore = (parti.length > 1) ? parti[1] : "Avversario";
                    
                            Platform.runLater(() -> homeController.aggiornaListaPartite(true, nomeCreatore));
                    
                        } else if (msg.equals("EMPTY")) {
                            Platform.runLater(() -> homeController.aggiornaListaPartite(false, ""));
                        }
                    }
                }
                // 3. Gestione Messaggi per il GIOCO (Scacchiera/Vittoria)
                else if (gameController != null) {
                    Platform.runLater(() -> gameController.gestisciMessaggioServer(msg));
                }
                
            }
        } catch (IOException e) {
            System.err.println("Connessione persa con il server.");
        }
    }
    private void mostraPopupAbbandono() {
        Platform.runLater(() -> {
            try {
                System.out.println("[DEBUG] Apertura del popup FXML in corso...");
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Tris_abbandonato.fxml"));
                Parent root = loader.load();
                
                Stage popupStage = new Stage();
                popupStage.initModality(Modality.APPLICATION_MODAL); // Blocca la finestra dietro
                
                // --- INIZIO NUOVA AGGIUNTA ---
                // Recuperiamo la finestra principale del gioco
                Stage mainStage = TrisLoginController.getPrimaryStage(); 
                if (mainStage != null) {
                    // Diciamo al popup che la sua "mamma" è la finestra principale.
                    // JavaFX lo centrerà automaticamente sopra di essa!
                    popupStage.initOwner(mainStage); 
                }
                // --- FINE NUOVA AGGIUNTA ---
                
                popupStage.setTitle("Partita Terminata");
                popupStage.setScene(new Scene(root));
                
                // Mostra il popup centrato
                popupStage.show();
                
            } catch (Exception e) {
                System.err.println("[ERRORE FATALE] Impossibile caricare Tris_abbandonato.fxml");
                e.printStackTrace();
            }
        });
    }
    public void inviaComando(String comando) {
    if (out != null) {
        out.println(comando);
        out.flush(); // Forza l'invio immediato dei dati
        System.out.println("[CLIENT] Inviato comando: " + comando);
    } else {
        System.err.println("[ERRORE] Impossibile inviare comando: output stream nullo.");
    }
}
    public void sendUsername(String name) {
    out.println("USER " + name);
    }
    private void CaricaHome(){
        Platform.runLater(() -> {
            try {
                // Carichiamo il file FXML della Home
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Tris_home.fxml"));
                Parent root = loader.load();

                // Recuperiamo lo Stage principale.
                // Se sei nel GameClient, usa il riferimento al controller della scacchiera
                // o recuperalo tramite un elemento grafico esistente.
                Stage mainStage = (Stage) TrisLoginController.getPrimaryStage();

                if (mainStage != null) {
                    mainStage.setScene(new Scene(root));
                    mainStage.setTitle("Tris - Home");
                    mainStage.show();
                }
            } catch (IOException ex) {
                System.err.println("Errore nel ritorno alla home: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
    }

    
    public int getPlayerID() { 
        return playerID; 
    }
    public TrisGameController getGameController() {
        return this.gameController;
    }
}