#include "globals.h"

GameRoom stanze[MAX_ROOMS];