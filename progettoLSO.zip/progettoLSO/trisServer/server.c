#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "server.h"
#include "game.h"
#include "globals.h"
// --- INIZIO GESTIONE CLASSIFICA SU FILE ---
void aggiorna_classifica(const char* username) {
    if (strcmp(username, "CPU_Bot") == 0) return; // Sicurezza extra: niente bot

    FILE *f = fopen("/data/leaderboard.txt", "r");
    char names[100][32];
    int scores[100];
    int count = 0;
    int found = 0;

    if (f) {
        while (fscanf(f, "%31s %d", names[count], &scores[count]) == 2) {
            if (strcmp(names[count], username) == 0) {
                scores[count]++; 
                found = 1;
            }
            count++;
        }
        fclose(f);
    }

    if (!found) {
        strcpy(names[count], username);
        scores[count] = 1;
        count++;
    }

    f = fopen("/data/leaderboard.txt", "w");
    if (f) {
        for (int i = 0; i < count; i++) {
            fprintf(f, "%s %d\n", names[i], scores[i]);
        }
        fclose(f);
    }
}

void invia_classifica(int sock, const char* requester) {
    FILE *f = fopen("/data/leaderboard.txt", "r");
    char names[100][32];
    int scores[100];
    int count = 0;

    if (f) {
        while (fscanf(f, "%31s %d", names[count], &scores[count]) == 2) {
            count++;
        }
        fclose(f);
    }

    // Ordina i giocatori dal più forte al più debole
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (scores[j] > scores[i]) {
                int temp_s = scores[i]; scores[i] = scores[j]; scores[j] = temp_s;
                char temp_n[32]; strcpy(temp_n, names[i]); strcpy(names[i], names[j]); strcpy(names[j], temp_n);
            }
        }
    }

    // Cerca la posizione di chi ha richiesto la classifica
    int my_rank = 0;
    int my_score = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(names[i], requester) == 0) {
            my_rank = i + 1; // La posizione è l'indice + 1
            my_score = scores[i];
            break;
        }
    }

    // Crea il messaggio: LEADERBOARD top1:10,top2:8|mia_posizione:mio_score
    char msg[512] = "LEADERBOARD ";
    int limit = (count < 5) ? count : 5;
    for (int i = 0; i < limit; i++) {
        char buf[64];
        snprintf(buf, sizeof(buf), "%s:%d,", names[i], scores[i]);
        strcat(msg, buf);
    }
    
    // Aggiunge la barra "|" per separare la top 5 dai dati personali
    char my_buf[64];
    snprintf(my_buf, sizeof(my_buf), "|%d:%d\n", my_rank, my_score);
    strcat(msg, my_buf);

    send(sock, msg, strlen(msg), 0);
}
// --- FINE GESTIONE CLASSIFICA ---
int fai_mossa_bot(char board[3][3]) {
    int r, c;
    
    for(r = 0; r < 3; r++) {
        for(c = 0; c < 3; c++) {
            if(board[r][c] == '_') {
                board[r][c] = 'O'; 
                if(check_winner(board) == 2) return 1;
                board[r][c] = '_'; 
            }
        }
    }
    
    for(r = 0; r < 3; r++) {
        for(c = 0; c < 3; c++) {
            if(board[r][c] == '_') {
                board[r][c] = 'X';
                if(check_winner(board) == 1) { 
                    board[r][c] = 'O'; 
                    return 1;
                }
                board[r][c] = '_'; 
            }
        }
    }
    
    if(board[1][1] == '_') {
        board[1][1] = 'O';
        return 1;
    }
    
    for(r = 0; r < 3; r++) {
        for(c = 0; c < 3; c++) {
            if(board[r][c] == '_') {
                board[r][c] = 'O';
                return 1;
            }
        }
    }
    return 0;
}
void *handle_client(void *arg) {
    pthread_detach(pthread_self());
    
    int sock = *(int*)arg;
    free(arg);
    char buffer[BUFFER_SIZE];
    int valread;

    while ((valread = recv(sock, buffer, BUFFER_SIZE - 1, 0)) > 0) {
        buffer[valread] = '\0';
        char *saveptr;
        char *line = strtok_r(buffer, "\r\n", &saveptr);
        
        while (line != NULL) {
            
            if (strncmp(line, "LIST", 4) == 0) {
                for (int i = 0; i < MAX_ROOMS; i++) {
                    pthread_mutex_lock(&stanze[i].mutex);
                    if (stanze[i].player_a_sock != -1 && stanze[i].status != TERMINATED && stanze[i].player_b_sock != -2) {
                        char msg[64];
                        
                        if (stanze[i].client_count == 2 || stanze[i].pending_b_sock != -1) {
                            snprintf(msg, sizeof(msg), "FULL_ROOM %s\n", stanze[i].player_a_name);
                        } else {
                            snprintf(msg, sizeof(msg), "AVAILABLE %s\n", stanze[i].player_a_name);
                        }
                        send(sock, msg, strlen(msg), 0);
                    }
                    pthread_mutex_unlock(&stanze[i].mutex);
                }
            }
            else if (strncmp(line, "GET_LEADERBOARD ", 16) == 0) {
                    char req_name[32] = "";
                    sscanf(line, "GET_LEADERBOARD %31s", req_name);
                    invia_classifica(sock, req_name);
            }
            else if (strncmp(line, "CREATE_BOT", 10) == 0) {
                for (int i = 0; i < MAX_ROOMS; i++) {
                    pthread_mutex_lock(&stanze[i].mutex);
                    if (stanze[i].player_a_sock == -1 && stanze[i].player_b_sock == -1) {
                        stanze[i].player_a_sock = sock;
                        stanze[i].player_b_sock = -2; // -2 identifica il BOT
                        strcpy(stanze[i].player_b_name, "CPU_Bot");
                        stanze[i].client_count = 2;
                        stanze[i].status = STARTED;
                        stanze[i].turn = 0;
                        send(sock, "WELCOME 0\n", 10, 0);
                        printf("[SERVER] Socket %d ha avviato partita contro il BOT (Stanza %d).\n", sock, i);
                        fflush(stdout);
                        pthread_mutex_unlock(&stanze[i].mutex);
                        break;
                    }
                    pthread_mutex_unlock(&stanze[i].mutex);
                }
            }
            else if (strncmp(line, "CREATE", 6) == 0) {
                for (int i = 0; i < MAX_ROOMS; i++) {
                    pthread_mutex_lock(&stanze[i].mutex);
                    if (stanze[i].player_a_sock == -1 && stanze[i].player_b_sock == -1) {
                        stanze[i].player_a_sock = sock;
                        stanze[i].client_count = 1;
                        stanze[i].turn = 0;
                         
                        stanze[i].status = WAITING;
                        memset(stanze[i].board, '_', sizeof(stanze[i].board));
                        send(sock, "WELCOME 0\n", 10, 0);
                        printf("[SERVER] Socket %d ha creato la stanza %d.\n", sock, i);
                        fflush(stdout); 
                        pthread_mutex_unlock(&stanze[i].mutex);
                        break;
                    }
                    pthread_mutex_unlock(&stanze[i].mutex);
                }
            }
            else if (strncmp(line, "JOIN_REQ ", 9) == 0) {
                char target_creator[32], my_name[32];
                if (sscanf(line, "JOIN_REQ %31s %31s", target_creator, my_name) == 2) {
                    int joined = 0;
                    for (int i = 0; i < MAX_ROOMS; i++) {
                        pthread_mutex_lock(&stanze[i].mutex);
                        if (stanze[i].client_count == 1 && strcmp(stanze[i].player_a_name, target_creator) == 0 && stanze[i].pending_b_sock == -1) {
                            stanze[i].pending_b_sock = sock;
                            strncpy(stanze[i].pending_b_name, my_name, 31);
                            
                            char msg[64];
                            snprintf(msg, sizeof(msg), "JOIN_REQUEST %s\n", my_name);
                            send(stanze[i].player_a_sock, msg, strlen(msg), 0);
                            joined = 1;
                            pthread_mutex_unlock(&stanze[i].mutex);
                            break;
                        }
                        pthread_mutex_unlock(&stanze[i].mutex);
                    }
                    if (!joined) send(sock, "FULL\n", 5, 0);
                }
            }
            
            int r_idx = find_room_by_sock(sock);
            if (r_idx != -1) {
                GameRoom *room = &stanze[r_idx];
                pthread_mutex_lock(&room->mutex);

                if (strncmp(line, "USER", 4) == 0) {
                    if (sock == room->player_a_sock) sscanf(line, "USER %s", room->player_a_name);
                    else if (sock == room->player_b_sock) sscanf(line, "USER %s", room->player_b_name);
                    broadcast_board(room); 
                }
                else if (strncmp(line, "ACCEPT_JOIN", 11) == 0) {
                    if (sock == room->player_a_sock && room->pending_b_sock != -1) {
                        room->player_b_sock = room->pending_b_sock;
                        strcpy(room->player_b_name, room->pending_b_name);
                        room->client_count = 2;
                        room->status = STARTED;
                        room->pending_b_sock = -1;
                        room->turn = 0;
                        memset(room->board, '_', sizeof(room->board));
                        send(room->player_b_sock, "WELCOME 1\n", 10, 0);
                        broadcast_board(room);
                    }
                }
                else if (strncmp(line, "DECLINE_JOIN", 12) == 0) {
                    if (sock == room->player_a_sock && room->pending_b_sock != -1) {
                        char msg_dec[64];
                        snprintf(msg_dec, sizeof(msg_dec), "JOIN_DECLINED %s\n", room->player_a_name);
                        send(room->pending_b_sock, msg_dec, strlen(msg_dec), 0);
                        room->pending_b_sock = -1; 
                    }
                }
                else if (strncmp(line, "MOVE", 4) == 0) {
                    int r, c;
                    if (sscanf(line, "MOVE %d %d", &r, &c) == 2) {
                        int is_a = (sock == room->player_a_sock);
                        int my_turn = (is_a) ? 0 : 1;
                        if (room->status == STARTED && room->turn == my_turn && r >= 0 && r < 3 && c >= 0 && c < 3 && room->board[r][c] == '_') {
                            room->board[r][c] = (is_a) ? 'X' : 'O';
                            int res = check_winner(room->board);
                            if (res == 0) { 
                                room->turn = (room->turn == 0) ? 1 : 0;
                                
                                if (room->turn == 1 && room->player_b_sock == -2 && room->status == STARTED) {
    
                                    fai_mossa_bot(room->board); 
                                    int res_bot = check_winner(room->board);
                                    if (res_bot == 0) {
                                        room->turn = 0; 
                                        broadcast_board(room);
                                    } else {
                                        room->status = TERMINATED;
                                        broadcast_board(room);
                                        if(res_bot == 2) send(room->player_a_sock, "DEFEAT\n", 7, 0);
                                        else send(room->player_a_sock, "DRAW\n", 5, 0);
                                    }
                                } else {
                                    broadcast_board(room);
                                }
                                
                            } else { 
                                broadcast_board(room);
                                room->status = TERMINATED;
                                if(res == 1) { 
                                    if (room->player_b_sock != -2) {
                                        aggiorna_classifica(room->player_a_name); 
                                    }
                                    send(room->player_a_sock, "VICTORY\n", 8, 0);
                                    if (room->player_b_sock > 0) send(room->player_b_sock, "DEFEAT\n", 7, 0);
                                } else if(res == 2) { 
                                    if (room->player_b_sock != -2) {
                                        aggiorna_classifica(room->player_b_name); 
                                    }
                                    send(room->player_a_sock, "DEFEAT\n", 7, 0);
                                    if (room->player_b_sock > 0) send(room->player_b_sock, "VICTORY\n", 8, 0);
                                } else { 
                                    send(room->player_a_sock, "DRAW\n", 5, 0);
                                    if (room->player_b_sock > 0) send(room->player_b_sock, "DRAW\n", 5, 0);
                                }
                            }
                        } else broadcast_board(room);
                    }
                }
                else if (strncmp(line, "REMATCH", 7) == 0) {
                    room->rematch_votes++;
                    if (room->player_b_sock == -2) room->rematch_votes++; // Il Bot accetta sempre!

                   if (room->client_count < 2 || room->rematch_votes == 2) {
                        memset(room->board, '_', sizeof(room->board));
                        room->status = (room->client_count == 2) ? STARTED : WAITING;
                        room->turn = 0;
                        room->rematch_votes = 0;
                        
                        if (room->player_a_sock > 0) send(room->player_a_sock, "REMATCH_ACCEPTED\n", 17, 0);
                        if (room->player_b_sock > 0) send(room->player_b_sock, "REMATCH_ACCEPTED\n", 17, 0);
                        
                        broadcast_board(room);
                    }
                }
                else if (strncmp(line, "LEAVE", 5) == 0) {
                    int avv_sock = (sock == room->player_a_sock) ? room->player_b_sock : room->player_a_sock;
                    char* chi_abbandona = (sock == room->player_a_sock) ? room->player_a_name : room->player_b_name;
                    if (avv_sock > 0) {
                        char msg_leave[64];
                        snprintf(msg_leave, sizeof(msg_leave), "OPPONENT_LEFT %s\n", chi_abbandona);
                        send(avv_sock, msg_leave, strlen(msg_leave), 0);
                    }
                    memset(room->board, '_', sizeof(room->board));
                    int voti_precedenti = room->rematch_votes;
                    room->rematch_votes = 0;
                    if (room->status == STARTED || (room->status == TERMINATED && voti_precedenti > 0)) {
                        room->status = WAITING;
                    }

                    if (sock == room->player_a_sock) {
                        room->player_a_sock = -1;
                        memset(room->player_a_name, 0, 32);
                        if (room->player_b_sock > 0) { // PROMOZIONE
                            room->player_a_sock = room->player_b_sock;
                            strcpy(room->player_a_name, room->player_b_name);
                            room->player_b_sock = -1;
                            memset(room->player_b_name, 0, 32);
                            usleep(50000); 
                            send(room->player_a_sock, "WELCOME 0\n", 10, 0);
                        } else if (room->player_b_sock == -2) {
                            room->player_b_sock = -1; // Elimina anche il bot
                            memset(room->player_b_name, 0, 32);
                        }
                    } else {
                        room->player_b_sock = -1;
                        memset(room->player_b_name, 0, 32);
                    }
                    
                    room->client_count--;
                    if (room->client_count <= 0) {
                        room->client_count = 0;
                        room->status = WAITING;
                        room->turn = 0;
                        room->pending_b_sock = -1;
                    }
                    usleep(50000);
                    broadcast_board(room); 
                }
                
                pthread_mutex_unlock(&room->mutex);
            }
            line = strtok_r(NULL, "\r\n", &saveptr);
        }
    }

    int r_idx = find_room_by_sock(sock);
    if (r_idx != -1) {
        GameRoom *room = &stanze[r_idx];
        pthread_mutex_lock(&room->mutex);
        
        int was_in_game = 0;
        int avv_sock = -1;

        if (sock == room->player_a_sock) {
            avv_sock = room->player_b_sock;
            room->player_a_sock = -1;
            memset(room->player_a_name, 0, 32);
            was_in_game = 1;
            if (avv_sock == -2) {
                room->player_b_sock = -1;
                memset(room->player_b_name, 0, 32);
            }
        } else if (sock == room->player_b_sock) {
            avv_sock = room->player_a_sock;
            room->player_b_sock = -1;
            memset(room->player_b_name, 0, 32);
            was_in_game = 1;
        } else if (sock == room->pending_b_sock) {
            room->pending_b_sock = -1;
            memset(room->pending_b_name, 0, 32);
        }
        
        if (was_in_game) {
            room->client_count--;
            if (avv_sock > 0 && (room->status == STARTED || room->status == TERMINATED)) {
                char msg_leave[64];
                char* chi_abbandona = (avv_sock == room->player_b_sock) ? room->player_a_name : room->player_b_name;
                snprintf(msg_leave, sizeof(msg_leave), "OPPONENT_LEFT %s\n", chi_abbandona);
                send(avv_sock, msg_leave, strlen(msg_leave), 0);
            }
            
            int voti_precedenti = room->rematch_votes;
            room->rematch_votes = 0;
            if (room->status == STARTED || (room->status == TERMINATED && voti_precedenti > 0)) {
                room->status = WAITING;
            }
            if (room->client_count <= 0) {
                room->client_count = 0;
                memset(room->board, '_', sizeof(room->board));
                room->status = WAITING;
                room->turn = 0;
                room->pending_b_sock = -1;
            }
        }
        pthread_mutex_unlock(&room->mutex);
    }

    printf("[SERVER] Client su socket %d disconnesso.\n", sock);
    fflush(stdout); // FORZA LA STAMPA SU DOCKER
    close(sock);
    return NULL;
}

int find_room_by_sock(int sock) {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (stanze[i].player_a_sock == sock || 
            stanze[i].player_b_sock == sock || 
            stanze[i].pending_b_sock == sock) {
            return i;
        }
    }
    return -1;
}

void handle_sigint(int sig) {
    printf("\n[SERVER] Spegnimento in corso...\n");
    fflush(stdout);
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (stanze[i].player_a_sock > 0) close(stanze[i].player_a_sock);
        if (stanze[i].player_b_sock > 0) close(stanze[i].player_b_sock);
        pthread_mutex_destroy(&stanze[i].mutex);
    }
    exit(0);
}