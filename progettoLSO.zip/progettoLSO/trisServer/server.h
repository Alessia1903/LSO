#ifndef SERVER_H
#define SERVER_H

void *handle_client(void *arg);
int find_room_by_sock(int sock);
void handle_sigint(int sig);

#endif