#ifndef SERVER_H
#define SERVER_H

void aggiorna_classifica(const char* username);
void invia_classifica(int sock, const char* requester);
int fai_mossa_bot(char board[3][3]);
void *handle_client(void *arg);
int find_room_by_sock(int sock);
void handle_sigint(int sig);

#endif