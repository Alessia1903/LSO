#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>

#include "game.h"
#include "globals.h"

int check_winner(char board[3][3]) {
    //righe e colonne
    for (int i = 0; i < 3; i++) {
        if (board[i][0] != '_' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) return (board[i][0] == 'X') ? 1 : 2;
        if (board[0][i] != '_' && board[0][i] == board[1][i] && board[1][i] == board[2][i]) return (board[0][i] == 'X') ? 1 : 2;
    }
    //diagonali
    if (board[1][1] != '_') {
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) return (board[1][1] == 'X') ? 1 : 2;
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0]) return (board[1][1] == 'X') ? 1 : 2;
    }
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == '_') return 0;   //continua la partita
    return 3;   //pareggio
}

void broadcast_board(GameRoom *room) {
    char msg[512]; 
    char* nameA = (strlen(room->player_a_name) > 0) ? room->player_a_name : "PlayerX";
    char* nameB = (room->player_b_sock != -1) ? ((strlen(room->player_b_name) > 0) ? room->player_b_name : "PlayerO") : "ATTESA";

    snprintf(msg, sizeof(msg), "BOARD %c%c%c%c%c%c%c%c%c NEXT %d NAMES %s %s\n", 
            room->board[0][0], room->board[0][1], room->board[0][2],
            room->board[1][0], room->board[1][1], room->board[1][2],
            room->board[2][0], room->board[2][1], room->board[2][2],
            room->turn, nameA, nameB);
            
    if (room->player_a_sock != -1) send(room->player_a_sock, msg, strlen(msg), 0);
    if (room->player_b_sock != -1) send(room->player_b_sock, msg, strlen(msg), 0);
}