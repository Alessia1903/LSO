#ifndef GAME_H
#define GAME_H

#include <pthread.h>

#define BUFFER_SIZE 1024
#define MAX_ROOMS 10
#define WAITING 0
#define STARTED 1
#define TERMINATED 2

typedef struct {
    char board[3][3];
    int player_a_sock;
    int player_b_sock;
    char player_a_name[32];
    char player_b_name[32];
    int turn;   
    int status; 
    int pending_b_sock;
    char pending_b_name[32];
    int client_count; 
    int rematch_votes;
    pthread_mutex_t mutex;
} GameRoom;

int check_winner(char board[3][3]);
void broadcast_board(GameRoom *room);

#endif