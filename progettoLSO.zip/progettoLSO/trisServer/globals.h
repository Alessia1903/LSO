#ifndef GLOBALS_H
#define GLOBALS_H

#include "game.h"

extern GameRoom stanze[MAX_ROOMS];

#endif