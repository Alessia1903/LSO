#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "server.h"
#include "globals.h"

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    signal(SIGINT, handle_sigint);

    for (int i = 0; i < MAX_ROOMS; i++) {
        memset(stanze[i].board, '_', sizeof(stanze[i].board));
        stanze[i].turn = 0;
        stanze[i].status = WAITING;
        stanze[i].player_a_sock = -1;
        stanze[i].player_b_sock = -1;
        stanze[i].pending_b_sock = -1;
        stanze[i].client_count = 0;
        stanze[i].rematch_votes = 0;
        memset(stanze[i].player_a_name, 0, 32);
        memset(stanze[i].player_b_name, 0, 32);
        memset(stanze[i].pending_b_name, 0, 32);
        pthread_mutex_init(&stanze[i].mutex, NULL);
    }

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(8080);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 10) < 0) {
        perror("listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("[SERVER] In ascolto sulla porta 8080.\n");

    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        if (new_socket < 0) {
            perror("accept failed");
            continue;
        }

        int *p_sock = malloc(sizeof(int));
        if (!p_sock) {
            perror("malloc failed");
            close(new_socket);
            continue;
        }
        *p_sock = new_socket;

        pthread_t tid;
        if (pthread_create(&tid, NULL, handle_client, p_sock) != 0) {
            perror("pthread_create failed");
            free(p_sock);
            close(new_socket);
            continue;
        }
        pthread_detach(tid);
    }

    close(server_fd);
    return 0;
}