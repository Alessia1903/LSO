import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class TrisRifiutoController {

    @FXML private Label messaggioLabel;
    private GameClient client;

    public void setClient(GameClient client) { this.client = client; }

    public void setMessaggio(String nomeProprietario) {
        messaggioLabel.setText("Oh no! " + nomeProprietario + " ha rifiutato la tua richiesta di unirti alla partita.");
    }

    @FXML public void tornaAllaHome(ActionEvent event) {
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();
        if (this.client != null && this.client.getGameController() != null) {
            this.client.getGameController().chiudiFinestraGioco();
        }
    }
}