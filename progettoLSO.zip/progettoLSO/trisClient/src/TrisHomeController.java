import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

public class TrisHomeController {

    @FXML private ListView<String> listaPartite;
    @FXML private Label nopartite;
    private GameClient client;

    public static boolean stoCreandoPartita = false;
    public static String nomeStanzaDaUnirsi = ""; 

    public static boolean stoCreandoPartitaBot = false;
    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
        if (this.client != null) {
            this.client.setHomeListener(this); 
            richiediLista();
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        richiediLista();
    }

    private void richiediLista() {
        if (client != null) {
            listaPartite.getItems().clear();
            nopartite.setVisible(true); 
            client.inviaComando("LIST");
        }
    }

    @FXML
    private void handleNewGame(ActionEvent event) {
        stoCreandoPartita = true;
        stoCreandoPartitaBot = false;
        cambiaScena(event);
    }
    @FXML
    private void handleJoinGame(MouseEvent event) {
        if (event.getClickCount() == 2 && !listaPartite.getSelectionModel().isEmpty()) {
            String selezionata = listaPartite.getSelectionModel().getSelectedItem();
            
            if (selezionata.endsWith("(PIENA)")) {
                mostraPopupPiena();
                return;
            }

            stoCreandoPartita = false;
            nomeStanzaDaUnirsi = selezionata.replace("Partita creata da: ", "").trim();
            cambiaScena(event);
        }
    }

    private void cambiaScena(Object event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_game.fxml"));
            Parent root = loader.load();
            TrisGameController gameController = loader.getController();
            if (!stoCreandoPartita && !stoCreandoPartitaBot) {
                gameController.impostaBloccoAttesa(true);
            } else {
                gameController.impostaBloccoAttesa(false); 
            }
            Stage nuovaFinestraGioco = new Stage();
            nuovaFinestraGioco.setScene(new Scene(root));
            nuovaFinestraGioco.setTitle("Tris In Partita - " + TrisLoginController.getUsername());
            nuovaFinestraGioco.setResizable(false);
            
            nuovaFinestraGioco.setOnCloseRequest(e -> {
                e.consume();
                System.out.println("Usa il tasto Abbandona per chiudere questa partita!");
            });

            nuovaFinestraGioco.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void aggiornaListaPartite(boolean disponibile, String nomeCreatore, boolean isFull) {
        Platform.runLater(() -> {
            if (disponibile) {
                if (nomeCreatore.equalsIgnoreCase(TrisLoginController.getUsername())) {
                    return; 
                }
                String testo = "Partita creata da: " + nomeCreatore;
                if (isFull) {
                    testo += " (PIENA)";
                }
                listaPartite.getItems().add(testo);
                if (!listaPartite.getItems().isEmpty()) {
                    nopartite.setVisible(false);
                }
            }
        });
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            if (this.client != null) this.client.disconnect();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_username.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tris - Login");
            stage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void mostraPopupPiena() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_piena.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Partita Piena - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }
    @FXML
    private void handlePlayBot(ActionEvent event) {
        stoCreandoPartita = false;
        stoCreandoPartitaBot = true; 
        cambiaScena(event);
    }
    @FXML
    private void handleClassifica(ActionEvent event) {
        if (client != null) {
            // Chiede la classifica e invia il MIO nome al server per sapere la mia posizione!
            client.inviaComando("GET_LEADERBOARD " + TrisLoginController.getUsername());
        }
    }

    public void mostraClassifica(String dati) {
        try {
            // 1. Carica la TUA pagina grafica
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_leaderboard.fxml"));
            javafx.scene.Parent root = loader.load();

            // 2. Passa i dati al controller della pagina
            TrisLeaderboardController controller = loader.getController();
            if (controller != null) {
                controller.impostaDati(dati);
            }

            // 3. Mostra il popup in primo piano
            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Classifica Globale");
            popupStage.setScene(new javafx.scene.Scene(root));
            popupStage.setResizable(false);
            popupStage.show();
            
        } catch (Exception e) {
            System.err.println("Errore nel caricamento della pagina classifica.");
            e.printStackTrace();
        }
    }
}