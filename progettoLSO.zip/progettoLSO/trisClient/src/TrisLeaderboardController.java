import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class TrisLeaderboardController {

    // Colleghiamo le 5 posizioni della tua grafica
    @FXML private Label pos1;
    @FXML private Label pos2;
    @FXML private Label pos3;
    @FXML private Label pos4;
    @FXML private Label pos5;
    
    // Colleghiamo la label per i tuoi punti in basso
    @FXML private Label labelMieStatistiche;

    public void impostaDati(String dati) {
        // Mettiamo i campi vuoti di default
        Label[] labels = {pos1, pos2, pos3, pos4, pos5};
        for (Label l : labels) {
            if (l != null) l.setText("---");
        }

        // Dividiamo i dati del server (Top 5 | Tue Statistiche)
        String[] sezioni = dati.split("\\|");
        String top5Str = (sezioni.length > 0) ? sezioni[0] : "";
        String mieStatistiche = (sezioni.length > 1) ? sezioni[1] : "0:0";

        // 1. Riempiamo la Top 5 nei tuoi 5 slot
        if (!top5Str.isEmpty() && !top5Str.equals(",")) {
            String[] giocatori = top5Str.split(",");
            for (int i = 0; i < giocatori.length && i < 5; i++) {
                if (giocatori[i].contains(":")) {
                    String[] parti = giocatori[i].split(":");
                    labels[i].setText(parti[0] + " (" + parti[1] + " vittorie)");
                }
            }
        }

        // 2. Mostriamo i tuoi punti personali in basso
        if (labelMieStatistiche != null) {
            String[] stats = mieStatistiche.split(":");
            if (stats.length == 2 && !stats[0].equals("0")) {
                labelMieStatistiche.setText("La tua posizione: " + stats[0] + "°\nVittorie: " + stats[1]);
            } else {
                labelMieStatistiche.setText("Non sei ancora in classifica.\nGioca e vinci contro un umano!");
            }
        }
    }

    @FXML
    public void chiudiPopup(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}