import java.io.*;
import java.net.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GameClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    
    private TrisGameController gameController;
    private TrisHomeController homeController;
    private int playerID = -1; 

    private String nomeAvversario;

    public GameClient(TrisGameController controller) {
        this.gameController = controller;
    }

    public void connect() throws IOException {
        this.socket = new Socket("localhost", 8080);
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        Thread listenerThread = new Thread(this::listenToServer);
        listenerThread.setDaemon(true); 
        listenerThread.start();
    }

    public void setController(TrisGameController controller) {
        this.gameController = controller;
        this.homeController = null; 
    }

    public void setHomeListener(TrisHomeController home) {
        this.homeController = home;
        this.gameController = null; 
    }

    public void sendMove(int r, int c) {
        if (out != null) out.println("MOVE " + r + " " + c);
    }

    public void richiediListaPartite() {
        if (out != null) out.println("LIST"); 
    }

    private void listenToServer() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println("[SERVER RAW]: " + line);
                final String msg = line.trim();

                if (msg.startsWith("WELCOME")) {
                    this.playerID = Integer.parseInt(msg.split(" ")[1]);
                    System.out.println("Assegnato PlayerID: " + playerID);
                    if (this.playerID == 1 && gameController != null) {
                        Platform.runLater(() -> gameController.impostaBloccoAttesa(false));
                    }
                }
                
                else if (msg.startsWith("OPPONENT_LEFT")) {
                    String[] parti = msg.split(" ", 2);
                    nomeAvversario = (parti.length > 1) ? parti[1] : "L'avversario";
                    System.out.println("[DEBUG] Ricevuto OPPONENT_LEFT!");
                    if (gameController != null) {
                        
                        if (gameController.isPartitaTerminata() || !gameController.staGiocando() || gameController.isInRivincita()) {
                            
                            System.out.println("[DEBUG] L'avversario è uscito, ma eravamo in lobby/fine partita. Attesa silenziosa.");
                            Platform.runLater(() -> gameController.impostaAttesaAvversario());
                            
                        } else {
                            mostraPopupAbbandono();
                        }
                    }
                }else if (msg.startsWith("JOIN_REQUEST")) {
                    String nomeRichiedente = msg.substring(13).trim();
                    if (gameController != null) {
                        Platform.runLater(() -> gameController.mostraPopupRichiesta(nomeRichiedente));
                    }
                }
                else if (msg.startsWith("JOIN_DECLINED")) {
                    String[] parti = msg.split(" ", 2);
                    String nomeProprietario = (parti.length > 1) ? parti[1] : "Il proprietario";
                    
                    if (gameController != null) {
                        Platform.runLater(() -> gameController.mostraPopupRifiuto(nomeProprietario));
                    }
                }
                else if (msg.equals("FULL")) {
                    if (gameController != null) {
                        Platform.runLater(() -> gameController.mostraPopupPiena());
                    }
                }              
                else if (msg.startsWith("AVAILABLE") || msg.startsWith("FULL_ROOM")) {
                    String[] parti = msg.split(" ");
                    String nomeCreatore = (parti.length > 1) ? parti[1] : "Avversario";
                    
                    boolean isFull = msg.startsWith("FULL_ROOM");
                    
                    if (homeController != null) {
                        Platform.runLater(() -> homeController.aggiornaListaPartite(true, nomeCreatore, isFull));
                    }
                }
                else if (gameController != null) {
                    Platform.runLater(() -> gameController.gestisciMessaggioServer(msg));
                }
                
            }
        } catch (IOException e) {
            System.err.println("Connessione persa con il server.");
        }
    }
    private void mostraPopupAbbandono() {
        Platform.runLater(() -> {
            try {
                System.out.println("[DEBUG] Apertura del popup FXML in corso...");
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_abbandonato.fxml"));
                Parent root = loader.load();

                TrisAbbandonatoController controller = loader.getController();
                controller.setMessaggio(nomeAvversario);
                
                Stage popupStage = new Stage();
                popupStage.initModality(Modality.APPLICATION_MODAL); 
                Stage mainStage = TrisLoginController.getPrimaryStage(); 
                if (mainStage != null) {
                    popupStage.initOwner(mainStage); 
                }
                
                popupStage.setTitle("Partita Terminata - " + TrisLoginController.getUsername());
                popupStage.setScene(new Scene(root));
                popupStage.setResizable(false);
                popupStage.setAlwaysOnTop(true);
                popupStage.toFront();
                popupStage.setOnCloseRequest(event -> event.consume());
                try {
                    javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                    popupStage.getIcons().add(iconaPopup);
                } catch (Exception e) {
                    System.out.println("Icona popup non trovata.");
                }
                popupStage.show();
                
            } catch (Exception e) {
                System.err.println("[ERRORE FATALE] Impossibile caricare Tris_abbandonato.fxml");
                e.printStackTrace();
            }
        });
    }
    public void inviaComando(String comando) {
    if (out != null) {
        out.println(comando);
        out.flush();
        System.out.println("[CLIENT] Inviato comando: " + comando);
    } else {
            System.err.println("[ERRORE] Impossibile inviare comando: output stream nullo.");
        }
    }
    public void sendUsername(String name) {
    out.println("USER " + name);
    }
    public int getPlayerID() { 
        return playerID; 
    }
    public TrisGameController getGameController() {
        return this.gameController;
    }
    public void disconnect() {
        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (socket != null && !socket.isClosed()) socket.close();
            System.out.println("[CLIENT] Disconnesso correttamente dal server.");
        } catch (IOException e) {
            System.err.println("Errore durante la disconnessione.");
        }
    }
}