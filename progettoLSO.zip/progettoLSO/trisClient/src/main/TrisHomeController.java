import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

public class TrisHomeController {

    @FXML private ListView<String> listaPartite;
    @FXML private Label nopartite;
    private GameClient client;

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
    
    if (this.client != null) {
        // Opzione A: Refresh manuale simulato
        listaPartite.getItems().add("Partita Globale (Server Online)");
        nopartite.setVisible(false);
        
        // Se vuoi che il passaggio alla scacchiera sia AUTOMATICO 
        // appena il server manda il BOARD, aggiungi questo:
        this.client.setHomeListener(this); 
    }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        // Puliamo la lista
        listaPartite.getItems().clear();

        // Dato che il tuo server C gestisce una partita alla volta:
        // Se siamo connessi, mostriamo una "Partita Globale" disponibile
        if (client != null) {
            listaPartite.getItems().add("Stanza Server: Partita in corso/attesa");
            nopartite.setVisible(false);
        } else {
            nopartite.setVisible(true);
        }
    }

    @FXML
    private void handleNewGame(ActionEvent event) {
        // Crea una nuova partita (va alla scacchiera)
        cambiaScena(event);
    }

    @FXML
    private void handleJoinGame(MouseEvent event) {
        // Entra nella partita selezionata con doppio click
        if (event.getClickCount() == 2 && !listaPartite.getSelectionModel().isEmpty()) {
            cambiaScena(event);
        }
    }

    private void cambiaScena(Object event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Tris_game.fxml"));
            Parent root = loader.load();

            Stage stage;
            if (event instanceof ActionEvent) {
                stage = (Stage) ((Node) ((ActionEvent) event).getSource()).getScene().getWindow();
            } else {
                stage = (Stage) ((Node) ((MouseEvent) event).getSource()).getScene().getWindow();
            }

            stage.setScene(new Scene(root));
            stage.setTitle("Tris - In Partita");
            stage.show();
        } catch (Exception e) {
            System.err.println("Errore nel caricamento della scacchiera!");
            e.printStackTrace();
        }
    }
    public void aggiornaListaPartite(boolean disponibile) {
    Platform.runLater(() -> {
        listaPartite.getItems().clear();
        if (disponibile) {
            listaPartite.getItems().add("Partita di: Avversario in attesa");
            nopartite.setVisible(false);
        } else {
            nopartite.setVisible(true);
        }
    });
    }
}
