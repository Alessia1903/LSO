import java.io.*;
import java.net.*;
import javafx.application.Platform;

public class GameClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    
    // Riferimenti ai controller per aggiornare l'interfaccia
    private TrisGameController gameController;
    private TrisHomeController homeController;
    
    private int playerID = -1; 

    public GameClient(TrisGameController controller) {
        this.gameController = controller;
    }

    public void connect() throws IOException {
        // Connessione al server Docker
        this.socket = new Socket("localhost", 8080);
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        // Unico thread di ascolto per tutta la durata dell'app
        Thread listenerThread = new Thread(this::listenToServer);
        listenerThread.setDaemon(true); 
        listenerThread.start();
    }

    // Metodi per cambiare il "destinatario" dei messaggi del server
    public void setController(TrisGameController controller) {
        this.gameController = controller;
        this.homeController = null; // Quando giochiamo, non siamo più nella home
    }

    public void setHomeListener(TrisHomeController home) {
        this.homeController = home;
        this.gameController = null; // Quando siamo in home, non siamo in gioco
    }

    public void sendMove(int r, int c) {
        if (out != null) out.println("MOVE " + r + " " + c);
    }

    public void richiediListaPartite() {
        if (out != null) out.println("LIST"); 
    }

    private void listenToServer() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println("[SERVER RAW]: " + line);
                final String msg = line;

                // 1. Gestione ID Giocatore (WELCOME 0 o 1)
                if (msg.startsWith("WELCOME")) {
                    this.playerID = Integer.parseInt(msg.split(" ")[1]);
                    System.out.println("Assegnato PlayerID: " + playerID);
                } 
                
                // 2. Gestione Messaggi per la HOME (Lista Partite)
                else if (homeController != null) {
                    if (msg.equals("AVAILABLE")) {
                        Platform.runLater(() -> homeController.aggiornaListaPartite(true));
                    } else if (msg.equals("EMPTY")) {
                        Platform.runLater(() -> homeController.aggiornaListaPartite(false));
                    }
                }
                
                // 3. Gestione Messaggi per il GIOCO (Scacchiera/Vittoria)
                else if (gameController != null) {
                    Platform.runLater(() -> gameController.gestisciMessaggioServer(msg));
                }
            }
        } catch (IOException e) {
            System.err.println("Connessione persa con il server.");
        }
    }

    public void sendUsername(String name) {
    out.println("USER " + name);
    }
    
    public int getPlayerID() { 
        return playerID; 
    }
}