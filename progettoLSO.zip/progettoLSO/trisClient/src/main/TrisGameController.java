import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.Node;
import javafx.application.Platform;

public class TrisGameController {
    @FXML private GridPane gridPane; 
    @FXML private Label statusLabel; // Aggiungi questa Label nel tuo FXML per i messaggi
    @FXML private Label labelTurno;
    @FXML private Label labelAvversario;
    
    private GameClient client;
    private Button[][] buttons = new Button[3][3]; // Matrice per gestire i bottoni

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
        
        if (this.client != null) {
            this.client.setController(this); 
            System.out.println("Sincronizzato con il server sulla scacchiera.");
        }

        // Mappa i bottoni del GridPane nella nostra matrice 3x3
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Integer r = GridPane.getRowIndex(node);
                Integer c = GridPane.getColumnIndex(node);
                // Gestione indici null (default a 0)
                int row = (r == null) ? 0 : r;
                int col = (c == null) ? 0 : c;
                buttons[row][col] = (Button) node;
            }
        }
    }

    // Unico metodo per gestire i messaggi dal GameClient
    public void gestisciMessaggioServer(String messaggio) {
        // Usiamo Platform.runLater per essere sicuri di toccare la UI nel thread giusto
        Platform.runLater(() -> {
            if (messaggio.startsWith("BOARD")) {
                aggiornaScacchiera(messaggio);
            } else if (messaggio.startsWith("VICTORY")) {
                statusLabel.setText("HAI VINTO! 🎉");
                gridPane.setDisable(true);
            } else if (messaggio.startsWith("DEFEAT")) {
                statusLabel.setText("HAI PERSO! 😢");
                gridPane.setDisable(true);
            } else if (messaggio.startsWith("DRAW")) {
                statusLabel.setText("PAREGGIO! 🤝");
            }
        });
    }

    private void aggiornaScacchiera(String messaggio) {
    // Dividiamo il messaggio: "BOARD X________ NEXT 1 NAMES Pippo ATTESA"
    String[] parti = messaggio.split(" ");
    
    // Controllo minimo: il messaggio deve avere almeno BOARD, GRIGLIA, NEXT, NUMERO
    if (parti.length < 4) {
        System.err.println("Messaggio del server troppo corto: " + messaggio);
        return;
    }

    String datiGriglia = parti[1];      // "X________"
    int turnoDi = Integer.parseInt(parti[3]); // 0 o 1
    int mioID = client.getPlayerID();

    // --- 1. GESTIONE NOMI E STATO AVVERSARIO ---
    // Verifichiamo se il server ha inviato anche i nomi (parti[5] e parti[6])
    if (parti.length >= 7 && parti[4].equalsIgnoreCase("NAMES")) {
        String nomeP1 = parti[5];
        String nomeP2 = parti[6];

        if (nomeP2.equalsIgnoreCase("ATTESA")) {
            labelAvversario.setText("In attesa di un avversario...");
            labelTurno.setText("Stai aspettando il giocatore O");
            gridPane.setDisable(true); // Non puoi muovere se sei solo
            aggiornaGraficaBottoni(datiGriglia);
            return; // Esci, non serve controllare il turno se manca l'avversario
        } else {
            String nomeAvversario = (mioID == 0) ? nomeP2 : nomeP1;
            labelAvversario.setText("Partita contro: " + nomeAvversario);
        }
    } else {
        // Fallback se il server manda il vecchio formato senza nomi
        labelAvversario.setText("Partita in corso");
    }

    // --- 2. AGGIORNAMENTO GRAFICO BOTTONI ---
    aggiornaGraficaBottoni(datiGriglia);

    // --- 3. GESTIONE TURNO ---
    if (mioID != turnoDi) {
        labelTurno.setText("Attesa turno avversario...");
        gridPane.setDisable(true); // Blocca i click
    } else {
        String mioSimbolo = (mioID == 0) ? "X" : "O";
        labelTurno.setText("Tocca a te! (" + mioSimbolo + ")");
        gridPane.setDisable(false); // Sblocca i click
    }
}

// Metodo di supporto per pulire il codice
private void aggiornaGraficaBottoni(String datiGriglia) {
    for (int i = 0; i < 9; i++) {
        int row = i / 3;
        int col = i % 3;
        char simbolo = datiGriglia.charAt(i);
        
        // Imposta il testo del bottone (X, O o vuoto)
        if (buttons[row][col] != null) {
            String testo = (simbolo == '_') ? "" : String.valueOf(simbolo);
            buttons[row][col].setText(testo);
        }
    }
}

    @FXML
    private void handleMossa(ActionEvent event) {
        Button btn = (Button) event.getSource();
        Integer r = GridPane.getRowIndex(btn);
        Integer c = GridPane.getColumnIndex(btn);
        
        client.sendMove(r == null ? 0 : r, c == null ? 0 : c);
    }
}