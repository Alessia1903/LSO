import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisFinePartitaController {

    private GameClient client; // Il client specifico di QUESTA partita

    public void setClient(GameClient client) {
        this.client = client;
    }

    @FXML
    public void tornaAllaHome(ActionEvent event) {
        if (this.client != null) {
            this.client.inviaComando("LEAVE");
            // Chiude la scacchiera specifica invece di ricaricare la Home
            if (this.client.getGameController() != null) {
                this.client.getGameController().chiudiFinestraGioco();
            }
        }
        // Chiude il popup
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();
    }

    @FXML
    public void giocaAncora(ActionEvent event) {
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();

        if (this.client != null) {
            if (this.client.getGameController() != null) {
                this.client.getGameController().setInRivincita(true);
                this.client.getGameController().impostaAttesaAvversario();
            }
            this.client.inviaComando("REMATCH");
        }
    }

    @FXML
    public void tastoGiocaAncoraCliccato(ActionEvent event) {
        if (this.client != null) {
            if (this.client.getGameController() != null) {
                this.client.getGameController().impostaBloccoAttesa(true);
            }
            this.client.inviaComando("REMATCH");
        }  
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();
    }
}