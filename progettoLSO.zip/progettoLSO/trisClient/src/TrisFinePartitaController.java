import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisFinePartitaController {

    @FXML
    public void tornaAllaHome(ActionEvent event) {
        chiudiPopupEVaiHome(event);
    }

    @FXML
    public void giocaAncora(ActionEvent event) {
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();

        GameClient client = TrisLoginController.getClient();
        if (client != null) {
            if (client.getGameController() != null) {
                client.getGameController().setInRivincita(true);
                client.getGameController().impostaAttesaAvversario();
            }
            client.inviaComando("REMATCH");
        }
    }
    @FXML
    public void tastoGiocaAncoraCliccato(ActionEvent event) {
        GameClient client = TrisLoginController.getClient();
        if (client != null) {
            if (client.getGameController() != null) {
                client.getGameController().impostaBloccoAttesa(true);
            }
            client.inviaComando("REMATCH");
        }  
        Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        popupStage.close();
    }

    private void chiudiPopupEVaiHome(ActionEvent event) {
        try {
            if (TrisLoginController.getClient() != null) {
                TrisLoginController.getClient().inviaComando("LEAVE");
            }

            Stage popupStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            popupStage.close();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_home.fxml"));
            Parent root = loader.load();

            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                mainStage.setScene(new Scene(root));
                mainStage.setTitle("Tris Home - " + TrisLoginController.getUsername());
                mainStage.setResizable(false);
                mainStage.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}