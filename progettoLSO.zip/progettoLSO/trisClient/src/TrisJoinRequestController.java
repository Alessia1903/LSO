import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.Node;
import javafx.stage.Stage;

public class TrisJoinRequestController {
    @FXML private Label messaggioLabel;
    private GameClient client;

    public void setClient(GameClient client) {
        this.client = client;
    }

    public void setMessaggio(String nomeRichiedente) {
        messaggioLabel.setText("Il giocatore " + nomeRichiedente + " vuole unirsi alla tua partita!");
    }

    @FXML public void accetta(ActionEvent event) {
        if (this.client != null) this.client.inviaComando("ACCEPT_JOIN");
        chiudiPopup(event);
    }

    @FXML public void rifiuta(ActionEvent event) {
        if (this.client != null) this.client.inviaComando("DECLINE_JOIN");
        chiudiPopup(event);
    }

    private void chiudiPopup(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}