import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;

import javafx.application.Platform;

public class TrisGameController {
    @FXML private GridPane gridPane; 
    @FXML private Label statusLabel; 
    @FXML private Label labelTurno;
    @FXML private Label labelAvversario;
    @FXML private Button btnAbbandona; 


    private String ultimaGriglia = "_________";
    
    private GameClient client;
    private Button[][] buttons = new Button[3][3]; 

    private boolean partitaTerminata = false;
    private boolean inRivincita = false;

    public boolean isPartitaTerminata() { return partitaTerminata; }
    public boolean isInRivincita() { return inRivincita; }
    public void setInRivincita(boolean val) { this.inRivincita = val; }

    @FXML
    public void initialize() {
        this.client = TrisLoginController.getClient();
        
        if (this.client != null) {
            this.client.setController(this); 
            System.out.println("Sincronizzato con il server sulla scacchiera.");
            if (TrisHomeController.stoCreandoPartita) {
                this.client.inviaComando("CREATE");
                this.client.sendUsername(TrisLoginController.getUsername());
            } else {
                this.client.inviaComando("JOIN_REQ " + TrisHomeController.nomeStanzaDaUnirsi + " " + TrisLoginController.getUsername());
                if (statusLabel != null) statusLabel.setText("In attesa dell'approvazione...");           
            }  
        }

        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Integer r = GridPane.getRowIndex(node);
                Integer c = GridPane.getColumnIndex(node);
                int row = (r == null) ? 0 : r;
                int col = (c == null) ? 0 : c;
                buttons[row][col] = (Button) node;
            }
        }
    }

    public void gestisciMessaggioServer(String messaggio) {
        Platform.runLater(() -> {
            try {
                if (messaggio.startsWith("BOARD")) {
                    aggiornaScacchiera(messaggio);
                } else if (messaggio.startsWith("VICTORY")) {
                    this.partitaTerminata = true; 
                    System.out.println("[DEBUG] Elaborazione Vittoria in corso...");
                    if (statusLabel != null) statusLabel.setText("HAI VINTO! 🎉");
                    if (gridPane != null) gridPane.setDisable(true);
                    mostraPopupRisultato("/fxml/Tris_vittoria.fxml");
                    
                } else if (messaggio.startsWith("DEFEAT")) {
                    this.partitaTerminata = true;
                    System.out.println("[DEBUG] Elaborazione Sconfitta in corso...");
                    if (statusLabel != null) statusLabel.setText("HAI PERSO! 😢");
                    if (gridPane != null) gridPane.setDisable(true);
                    mostraPopupRisultato("/fxml/Tris_sconfitta.fxml");
                    
                } else if (messaggio.startsWith("DRAW")) {
                    this.partitaTerminata = true; 
                    System.out.println("[DEBUG] Elaborazione Pareggio in corso...");
                    if (statusLabel != null) statusLabel.setText("PAREGGIO! 🤝");
                    if (gridPane != null) gridPane.setDisable(true);
                    mostraPopupRisultato("/fxml/Tris_pareggio.fxml");
                }
            } catch (Exception e) {
                System.err.println("[ERRORE GRAVE] Crash durante la gestione del messaggio: " + messaggio);
                e.printStackTrace();
            }
        });
    }

    private void mostraPopupRisultato(String nomeFileFxml) {
        try {
            System.out.println("[DEBUG] Tento di caricare il popup: " + nomeFileFxml);
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource(nomeFileFxml));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL); 
            
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) {
                popupStage.initOwner(mainStage); 
            }
            
            popupStage.setTitle("Fine Partita - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();           
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
            System.out.println("[DEBUG] Popup aperto con successo!");
            
        } catch (Exception e) {
            System.err.println("[ERRORE] Impossibile caricare il popup: " + nomeFileFxml);
            e.printStackTrace();
        }
    }

    private void aggiornaScacchiera(String messaggio) {
    String[] parti = messaggio.split(" ");
    
    if (parti.length < 4) {
        System.err.println("Messaggio del server troppo corto: " + messaggio);
        return;
    }

    String datiGriglia = parti[1];
    this.ultimaGriglia = datiGriglia;
    int turnoDi = Integer.parseInt(parti[3]);
    int mioID = client.getPlayerID();
    System.out.println("[DEBUG GIOCO] Ricevuta scacchiera. Mio ID: " + mioID + " | Turno di: " + turnoDi);

    this.partitaTerminata = false;
    if (!isScacchieraVuota()) {
        this.inRivincita = false; 
    }
    if (parti.length >= 7 && parti[4].equalsIgnoreCase("NAMES")) {
        String nomeP1 = parti[5];
        String nomeP2 = parti[6];

        String mioNome = TrisLoginController.getUsername();

        if (nomeP2.equalsIgnoreCase("ATTESA")) {
            if (labelAvversario != null) labelAvversario.setText("In attesa di un avversario...");
            if (labelTurno != null) labelTurno.setText("Stai aspettando lo sfidante...");
            if (gridPane != null) gridPane.setDisable(true);
            aggiornaGraficaBottoni(datiGriglia);
            return;
        } else {
            String nomeAvversario = nomeP1.equalsIgnoreCase(mioNome) ? nomeP2 : nomeP1;
            if (labelAvversario != null) labelAvversario.setText("Partita contro: " + nomeAvversario);        
        }
    }
    aggiornaGraficaBottoni(datiGriglia);

    if (mioID != turnoDi) {
        if (labelTurno != null) labelTurno.setText("Attesa turno avversario...");
        if (gridPane != null) gridPane.setDisable(true);
        System.out.println("[DEBUG GIOCO] Scacchiera BLOCCATA (non è il mio turno).");
    } else {
        String mioSimbolo = (mioID == 0) ? "X" : "O";
        labelTurno.setText("Tocca a te! (" + mioSimbolo + ")");
        if (labelTurno != null) labelTurno.setText("Tocca a te! (" + mioSimbolo + ")");
        
        if (gridPane != null) {
            gridPane.setDisable(false);
            System.out.println("[DEBUG GIOCO] Scacchiera SBLOCCATA con successo!");
        }
    }
}

    private void aggiornaGraficaBottoni(String datiGriglia) {
        
        String stileBase = "-fx-background-color: white; "
                         + "-fx-border-color: black; "
                         + "-fx-background-radius: 5; "
                         + "-fx-border-radius: 5; "
                         + "-fx-border-width: 1; "
                         + "-fx-font-size: 30px; "
                         + "-fx-font-weight: bold; ";

        for (int i = 0; i < 9; i++) {
            int row = i / 3;
            int col = i % 3;
            char simbolo = datiGriglia.charAt(i);
            
            if (buttons[row][col] != null) {
                if (simbolo == 'X') {
                    buttons[row][col].setText("X");
                    buttons[row][col].setStyle(stileBase + "-fx-text-fill: #F30D61;");
                    
                } else if (simbolo == 'O') {
                    buttons[row][col].setText("O"); 
                    buttons[row][col].setStyle(stileBase + "-fx-text-fill: #ECE867;");
                    
                } else {
                    buttons[row][col].setText("");
                    buttons[row][col].setStyle(stileBase); 
                }
            }
        }
    }

    @FXML
    private void handleMossa(ActionEvent event) {
        Button btn = (Button) event.getSource();
        Integer r = GridPane.getRowIndex(btn);
        Integer c = GridPane.getColumnIndex(btn);
        
        client.sendMove(r == null ? 0 : r, c == null ? 0 : c);
    }

    @FXML
    private void handleAbbandona(ActionEvent event) {
        if (client != null) {
            client.inviaComando("LEAVE");
        }
        tornaAllaHome(event);
    }

    private void tornaAllaHome(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/Tris_home.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tris Home - " + TrisLoginController.getUsername());
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void impostaAttesaAvversario() {
        if (statusLabel != null) statusLabel.setText("In attesa di un nuovo sfidante...");
        if (labelTurno != null) labelTurno.setText("");
        if (labelAvversario != null) labelAvversario.setText("Ora sei il proprietario della stanza!");
        if (gridPane != null) gridPane.setDisable(true);
        
        String stileVuoto = "-fx-background-color: white; -fx-border-color: black; -fx-background-radius: 5; -fx-border-radius: 5; -fx-border-width: 1;";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j] != null) {
                    buttons[i][j].setText("");
                    buttons[i][j].setStyle(stileVuoto);
                }
            }
        }
    }
    public boolean isScacchieraVuota() {
        return "_________".equals(ultimaGriglia);
    }
    public void mostraPopupRichiesta(String nomeRichiedente) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_joinRequest.fxml"));
            Parent root = loader.load();

            TrisJoinRequestController controller = loader.getController();
            controller.setMessaggio(nomeRichiedente); 

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Richiesta di partecipazione - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void mostraPopupRifiuto() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_rifiuto.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Richiesta Rifiutata - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true);
            popupStage.toFront(); 
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }
    public boolean staGiocando() {
        if (labelAvversario == null) return false;
        return labelAvversario.getText().startsWith("Partita contro");
    }
    public void mostraPopupRifiuto(String nomeProprietario) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_rifiuto.fxml"));
            Parent root = loader.load();

            TrisRifiutoController controller = loader.getController();
            controller.setMessaggio(nomeProprietario);

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Richiesta Rifiutata - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }
    public void mostraPopupPiena() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_piena.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            Stage mainStage = TrisLoginController.getPrimaryStage();
            if (mainStage != null) popupStage.initOwner(mainStage);

            popupStage.setTitle("Partita Piena - " + TrisLoginController.getUsername());
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.setAlwaysOnTop(true); 
            popupStage.toFront();
            popupStage.setOnCloseRequest(event -> event.consume());
            try {
                javafx.scene.image.Image iconaPopup = new javafx.scene.image.Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                popupStage.getIcons().add(iconaPopup);
            } catch (Exception e) {
                System.out.println("Icona popup non trovata.");
            }
            popupStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void impostaBloccoAttesa(boolean inAttesa) {
        if (btnAbbandona != null) {
            btnAbbandona.setDisable(inAttesa);
        }
        if (inAttesa && statusLabel != null) {
            statusLabel.setText("In attesa che l'avversario accetti...");
        }
        
    }
}