import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class TrisGuiClient extends Application {


    @Override
    public void start(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_username.fxml"));
            Parent root = loader.load();
            
            Scene scene = new Scene(root);
            TrisLoginController.setPrimaryStage(primaryStage);
            primaryStage.setTitle("Tris Login");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.setOnCloseRequest(event -> {
                long finestreVisibili = javafx.stage.Window.getWindows().stream()
                        .filter(w -> w instanceof Stage && w.isShowing())
                        .count();

                if (finestreVisibili > 1) {
                    event.consume();
                    System.out.println("[CLIENT] Chiusura bloccata: è presente un popup a schermo.");
                } else {
                    if (TrisLoginController.getClient() != null) {
                        TrisLoginController.getClient().disconnect();
                    }
                    javafx.application.Platform.exit();
                    System.exit(0);
                }
            });
            primaryStage.setOnCloseRequest(event -> {
                if (primaryStage.getTitle() != null && primaryStage.getTitle().startsWith("Tris In Partita")) {
                    event.consume(); 
                    System.out.println("[CLIENT] Tentativo di chiusura dalla 'X' bloccato: sei in partita!");
                } else {
                    if (TrisLoginController.getClient() != null) {
                        TrisLoginController.getClient().disconnect();
                    }
                    javafx.application.Platform.exit();
                    System.exit(0);
                }
            });
            primaryStage.show();
            try {
                Image iconaApp = new Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                primaryStage.getIcons().add(iconaApp);
            } catch (Exception e) {
                System.out.println("Attenzione: Impossibile caricare l'icona personalizzata.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Errore nel caricamento del file FXML. Verifica il percorso.");
        }
    }

    public static void main(String[] args) {
        launch(args);
  
    }
}