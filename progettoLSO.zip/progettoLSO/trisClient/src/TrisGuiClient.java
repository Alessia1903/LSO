import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.*;
import java.net.Socket;

public class TrisGuiClient extends Application {
    private Button[][] boardButtons = new Button[3][3];
    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;
    private GridPane gameGrid = new GridPane();
    private int myPlayerId = -1;
    private Stage primaryStage; 
    private Label statusLabel = new Label("in attesa dell'avversario...");
    private boolean gameActive = true;

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage; // <--- Salviamo il riferimento

        
        gameGrid.setHgap(10);
        gameGrid.setVgap(10);
        gameGrid.setAlignment(Pos.CENTER);

        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                Button btn = new Button("");
                btn.setPrefSize(80, 80);
                btn.setStyle("-fx-font-size: 24; -fx-font-weight: bold;");
                btn.setDisable(true); // Disabilitati all'inizio

                int row = r;
                int col = c;
                btn.setOnAction(e -> sendMove(row, col));

                boardButtons[r][c] = btn;
                gameGrid.add(btn, c, r);
            }
        }

        statusLabel.setStyle("-fx-font-size: 16; -fx-font-weight: bold;");
        
        VBox root = new VBox(20, new Label("TRIS"), gameGrid, statusLabel);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        Scene scene = new Scene(root, 400, 500);
        primaryStage.setTitle("Tris Client");
        primaryStage.setScene(scene);
        primaryStage.show();

        connectToServer();

        primaryStage.setOnCloseRequest(event -> {
            try {
                if (socket != null) socket.close();
            } catch (IOException e) { e.printStackTrace(); }
            Platform.exit();
            System.exit(0);
        });
    }

    private void connectToServer() {
    new Thread(() -> {
        try {
            socket = new Socket("localhost", 8080);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String line;
            while ((line = in.readLine()) != null) {
                final String finalLine = line.trim(); // Pulizia spazi bianchi
                System.out.println("[DEBUG] Ricevuto: " + finalLine);

                // 1. GESTIONE FINE PARTITA
                if (finalLine.equals("VICTORY") || finalLine.equals("DEFEAT") || finalLine.equals("DRAW")) {
                    gameActive = false; // Lucchetto logico immediato
                    syncGameLock();     // Chiama il blocco fisico
                    
                    Platform.runLater(() -> {
                        statusLabel.setText("FINE: " + finalLine);
                    });
                    continue; 
                }

                // 2. GESTIONE SCACCHIERA
                if (finalLine.startsWith("BOARD")) {
                    String[] parts = finalLine.split("\\s+");
                    if (parts.length >= 4) {
                        String boardStr = parts[1];
                        int nextPlayer = Integer.parseInt(parts[3]);

                        Platform.runLater(() -> {
                            // CONTROLLO CRITICO: se il gioco è finito, non fare NULLA
                            if (!gameActive) {
                                syncGameLock();
                                return;
                            }

                            for (int i = 0; i < 9; i++) {
                                int r = i / 3;
                                int c = i % 3;
                                char symbol = boardStr.charAt(i);
                                boardButtons[r][c].setText(symbol == '_' ? "" : String.valueOf(symbol));

                                // Sblocco solo se il gioco è attivo e tocca a me
                                boolean mioTurno = (nextPlayer == myPlayerId);
                                boardButtons[r][c].setDisable(!(symbol == '_' && mioTurno));
                            }
                            statusLabel.setText(nextPlayer == myPlayerId ? "Tocca a te!" : "Attesa avversario...");
                        });
                    }
                }
            }
        } catch (IOException e) {
            Platform.runLater(() -> statusLabel.setText("Errore di connessione!"));
        }
    }).start();
}

    private void sendMove(int row, int col) {
    // Aggiungiamo il controllo gameActive per sicurezza
    if (out != null && gameActive) {
        out.println("MOVE " + row + " " + col);
        out.flush(); // Forza l'invio immediato del pacchetto

        // Usiamo Platform.runLater per disabilitare l'interfaccia in modo sicuro
        Platform.runLater(() -> {
            for (int r = 0; r < 3; r++) {
                for (int c = 0; c < 3; c++) {
                    boardButtons[r][c].setDisable(true);
                }
            }
        });
    }
}
private void syncGameLock() {
    Platform.runLater(() -> {
        if (!gameActive) {
            gameGrid.setDisable(true);
            // Blocco extra: disabilita fisicamente ogni bottone uno per uno
            for (Button[] row : boardButtons) {
                for (Button btn : row) {
                    btn.setDisable(true);
                }
            }
        }
    });
}

    public static void main(String[] args) {
        launch(args);
    }
}