import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class TrisGuiClient extends Application {


    @Override
    public void start(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tris_username.fxml"));
            Parent root = loader.load();
            
            Scene scene = new Scene(root);
            TrisLoginController.setPrimaryStage(primaryStage);
            primaryStage.setTitle("Tris - Login");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
            try {
                Image iconaApp = new Image(getClass().getResourceAsStream("/image/Logo_astratto_con_X_magenta.png"));
                primaryStage.getIcons().add(iconaApp);
            } catch (Exception e) {
                System.out.println("Attenzione: Impossibile caricare l'icona personalizzata.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Errore nel caricamento del file FXML. Verifica il percorso.");
        }
    }

    public static void main(String[] args) {
        launch(args);
  
    }
}