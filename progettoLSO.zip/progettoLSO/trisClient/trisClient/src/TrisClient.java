import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TrisClient {
    private static final String SERVER_IP = "127.0.0.1";
    private static final int SERVER_PORT = 8080;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT)) {
            System.out.println("Connesso al Server Tris!");

            // Thread per ricevere messaggi dal server in background
            Thread receiveThread = new Thread(() -> {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                    String serverMessage;
                    while ((serverMessage = in.readLine()) != null) {
                        System.out.println("\n[SERVER]: " + serverMessage);
                        System.out.print("> "); // Prompt per l'utente
                    }
                } catch (IOException e) {
                    System.out.println("Connessione chiusa dal server.");
                }
            });
            receiveThread.start();

            // Gestione invio messaggi (Main Thread)
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Digita un comando (es: NEW Mario, JOIN 1, MOVE 0 0, QUIT_SERVER):");
            while (true) {
                System.out.print("> ");
                String userInput = scanner.nextLine();
                
                if (userInput.equalsIgnoreCase("exit")) break;
                
                out.println(userInput); // Invia al server
            }

        } catch (IOException e) {
            System.err.println("Errore di connessione: " + e.getMessage());
        }
    }
}