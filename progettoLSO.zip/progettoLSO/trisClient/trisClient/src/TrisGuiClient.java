import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;

public class TrisGuiClient extends Application {
    private PrintWriter out;
    private TextArea logArea = new TextArea();
    private TextField inputField = new TextField();
    private Socket socket;
    private Button[][] boardButtons = new Button[3][3]; // Matrice di 9 bottoni

    @Override
    public void start(Stage primaryStage) {
        
        logArea.setEditable(false);
        logArea.setPrefHeight(300);

        inputField.setPromptText("Inserisci comando (es: NEW Mario)");
        inputField.setOnAction(e -> sendCommand()); // Invia quando premi INVIO

        Button sendBtn = new Button("Invia");
        sendBtn.setOnAction(e -> sendCommand());

        VBox root = new VBox(10, new Label("Log Server:"), logArea, inputField, sendBtn);
        root.setPadding(new Insets(15));

        Scene scene = new Scene(root, 400, 450);
        primaryStage.setTitle("Client Tris - JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();

        connectToServer();
        primaryStage.setOnCloseRequest(event -> {
    System.out.println("Chiusura dell'applicazione in corso...");
    try {
        if (out != null) {
            // Opzionale: invia un messaggio di "addio" al server C
            out.println("EXIT"); 
        }
        if (socket != null && !socket.isClosed()) {
            socket.close(); // Chiude fisicamente la connessione
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    Platform.exit();
    System.exit(0);
    });

    GridPane gameGrid = new GridPane();
    gameGrid.setHgap(5);
    gameGrid.setVgap(5);

    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) {
            Button btn = new Button("");
            btn.setPrefSize(60, 60);
            btn.setStyle("-fx-font-size: 20; -fx-font-weight: bold;");
            
            int row = r;
            int col = c;
            
            // Quando clicchi, invia la mossa al server C
            btn.setOnAction(e -> sendMove(row, col));
            
            boardButtons[r][c] = btn;
            gameGrid.add(btn, c, r);
        }
    }

    // Aggiungiamo la griglia al layout principale (VBox)
    VBox root = new VBox(10, new Label("Log Server:"), logArea, gameGrid, inputField);
    // ... restanti impostazioni dello Stage ...
    }

    private void connectToServer() {
        new Thread(() -> {
            try {
                socket = new Socket("127.0.0.1", 8080);
                out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                updateLog("Connesso al server C!");

                String line;
                while ((line = in.readLine()) != null) {
    String finalLine = line;
    
    if (finalLine.startsWith("BOARD")) {
        String boardState = finalLine.split(" ")[1];
        Platform.runLater(() -> updateBoardUI(boardState));
    } 
    else if (finalLine.equals("VICTORY")) {
        showGameOverAlert("Complimenti!", "Hai vinto la partita! 🎉");
    } 
    else if (finalLine.equals("DEFEAT")) {
        showGameOverAlert("Peccato...", "Hai perso. Ritenta, sarai più fortunato!");
    } 
    else if (finalLine.equals("DRAW")) {
        showGameOverAlert("Pareggio!", "La partita è finita in parità.");
    }
    
    // Log generico nella TextArea
    Platform.runLater(() -> logArea.appendText("SERVER: " + finalLine + "\n"));
}
            } catch (IOException e) {
                updateLog("Errore: " + e.getMessage());
            }
            
        }).start();
    }

private void showGameOverAlert(String title, String message) {
    Platform.runLater(() -> {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fine Partita");
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
        
        // Dopo il click su OK, resettiamo i bottoni per una nuova partita
        resetBoardUI();
    });
}

private void resetBoardUI() {
    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) {
            boardButtons[r][c].setText("");
            boardButtons[r][c].setDisable(false);
        }
    }
}

    private void updateBoardUI(String state) {
    for (int i = 0; i < 9; i++) {
        int r = i / 3;
        int c = i % 3;
        char symbol = state.charAt(i);
        boardButtons[r][c].setText(symbol == '_' ? "" : String.valueOf(symbol));
    }
}

    private void sendCommand() {
        String cmd = inputField.getText();
        if (out != null && !cmd.isEmpty()) {
            out.println(cmd);
            inputField.clear();
            logArea.appendText("TU: " + cmd + "\n");
        }
    }

    private void updateLog(String msg) {
        Platform.runLater(() -> logArea.appendText(msg + "\n"));
    }

    public static void main(String[] args) {
        launch(args);
    }
}