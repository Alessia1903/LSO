#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUFFER_SIZE 1024
#define WAITING 0
#define STARTED 1
#define TERMINATED 2

typedef struct {
    char board[3][3];
    int player_a_sock;
    int player_b_sock;
    int turn;   
    int status; 
    pthread_mutex_t mutex;
} Game;

// Global variables
Game la_mia_partita;
int client_count = 0; // Spostata globale per essere vista da handle_client
void handle_sigint(int sig) {
    printf("\n[SERVER] Ricevuto segnale di chiusura (%d). Spegnimento in corso...\n", sig);
    
    // Chiudi i socket attivi
    close(la_mia_partita.player_a_sock);
    close(la_mia_partita.player_b_sock);
    
    // Distruggi il mutex
    pthread_mutex_destroy(&la_mia_partita.mutex);
    
    exit(0);
}
// 1. Controllo vincitore
int check_winner(char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        // Righe e Colonne
        if (board[i][0] != '_' && board[i][0] == board[i][1] && board[i][1] == board[i][2])
            return (board[i][0] == 'X') ? 1 : 2;
        if (board[0][i] != '_' && board[0][i] == board[1][i] && board[1][i] == board[2][i])
            return (board[0][i] == 'X') ? 1 : 2;
    }
    // Diagonali
    if (board[1][1] != '_') {
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) return (board[1][1] == 'X') ? 1 : 2;
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0]) return (board[1][1] == 'X') ? 1 : 2;
    }
    // Pareggio o Continua
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == '_') return 0;
    return 3; 
}

// 2. Notifica stato scacchiera
void broadcast_board() {
    char msg[256];
    int next = la_mia_partita.turn;
    if (la_mia_partita.status == TERMINATED) {
        next = -1;
    }
    // Costruiamo la stringa: BOARD (9 simboli) NEXT (0 o 1)
    // Usiamo uno spazio chiaro tra ogni parte
    snprintf(msg, sizeof(msg), "BOARD %c%c%c%c%c%c%c%c%c NEXT %d\n", 
            la_mia_partita.board[0][0], la_mia_partita.board[0][1], la_mia_partita.board[0][2],
            la_mia_partita.board[1][0], la_mia_partita.board[1][1], la_mia_partita.board[1][2],
            la_mia_partita.board[2][0], la_mia_partita.board[2][1], la_mia_partita.board[2][2],
            la_mia_partita.turn);
            
    // IMPORTANTE: Invia a entrambi i socket
    if (la_mia_partita.player_a_sock != -1) {
        send(la_mia_partita.player_a_sock, msg, strlen(msg), 0);
    }
    if (la_mia_partita.player_b_sock != -1) {
        send(la_mia_partita.player_b_sock, msg, strlen(msg), 0);
    }
    printf("[SERVER] Inviato aggiornamento: %s", msg); 
}

// 3. Gestione Client
void *handle_client(void *arg) {
    int sock = *(int*)arg;
    free(arg);
    char buffer[BUFFER_SIZE];
    int valread;

    printf("[SERVER] Client connesso su socket %d\n", sock);

    while ((valread = recv(sock, buffer, BUFFER_SIZE - 1, 0)) > 0) {
        buffer[valread] = '\0';
        
        // --- LOGICA ANTI-BLOCCO: Spezza i messaggi basandosi su \n o \r ---
        char *saveptr;
        char *line = strtok_r(buffer, "\r\n", &saveptr);
        
        while (line != NULL) {
            printf("[DEBUG] Ricevuto comando pulito: '%s'\n", line);

            if (strncmp(line, "MOVE", 4) == 0) {
                int r, c;
                if (sscanf(line, "MOVE %d %d", &r, &c) == 2) {
                    pthread_mutex_lock(&la_mia_partita.mutex);
                    
                    int is_player_a = (sock == la_mia_partita.player_a_sock);
                    
                    // Controlli di validità
                    if (la_mia_partita.status == STARTED && 
                        ((la_mia_partita.turn == 0 && is_player_a) || (la_mia_partita.turn == 1 && !is_player_a)) &&
                        r >= 0 && r < 3 && c >= 0 && c < 3 && la_mia_partita.board[r][c] == '_') {
                        
                        la_mia_partita.board[r][c] = is_player_a ? 'X' : 'O';
                        int res = check_winner(la_mia_partita.board);

                        if (res == 0) {
                            la_mia_partita.turn = (la_mia_partita.turn == 0) ? 1 : 0;
                            broadcast_board();
                        } else {
                            broadcast_board();
                            la_mia_partita.status = TERMINATED;
                            if(res == 1) { 
                                send(la_mia_partita.player_a_sock, "VICTORY\n", 8, 0);
                                send(la_mia_partita.player_b_sock, "DEFEAT\n", 7, 0);
                            } else if(res == 2) { 
                                send(la_mia_partita.player_a_sock, "DEFEAT\n", 7, 0);
                                send(la_mia_partita.player_b_sock, "VICTORY\n", 8, 0);
                            } else { 
                                send(la_mia_partita.player_a_sock, "DRAW\n", 5, 0);
                                send(la_mia_partita.player_b_sock, "DRAW\n", 5, 0);
                            }
                        }
                    } else {
                        // Se la mossa non è valida, rimandiamo la board per "sbloccare" il client
                        broadcast_board();
                    }
                    pthread_mutex_unlock(&la_mia_partita.mutex);
                }
            } else if (strncmp(line, "RESTART", 7) == 0) {
                pthread_mutex_lock(&la_mia_partita.mutex);
                memset(la_mia_partita.board, '_', sizeof(la_mia_partita.board));
                la_mia_partita.turn = 0;
                la_mia_partita.status = STARTED;
                broadcast_board();
                pthread_mutex_unlock(&la_mia_partita.mutex);
            }
            
            line = strtok_r(NULL, "\r\n", &saveptr); // Prendi il prossimo comando nel buffer
        }
    }

    // Gestione disconnessione (codice che avevi già...)
    printf("[SERVER] Client %d disconnesso\n", sock);
    close(sock);
    return NULL;
}

// 4. MAIN
int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    signal(SIGINT, handle_sigint);

    memset(la_mia_partita.board, '_', sizeof(la_mia_partita.board));
    la_mia_partita.turn = 0;
    la_mia_partita.status = WAITING;
    pthread_mutex_init(&la_mia_partita.mutex, NULL);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(8080);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 3);

    printf("[SERVER] In ascolto sulla porta 8080...\n");

    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        
        pthread_mutex_lock(&la_mia_partita.mutex);
        if (client_count < 2) {
            if (client_count == 0) {
                la_mia_partita.player_a_sock = new_socket;
                send(new_socket, "WELCOME 0\n", 10, 0);
            } else {
                la_mia_partita.player_b_sock = new_socket;
                send(new_socket, "WELCOME 1\n", 10, 0);
                la_mia_partita.status = STARTED;
            }
            client_count++;
            printf("[SERVER] Giocatore connesso. Totale: %d\n", client_count);
            
            if (client_count == 2) {
                la_mia_partita.status = STARTED;
                broadcast_board();
            }

            pthread_t tid;
            int *p_sock = malloc(sizeof(int));
            *p_sock = new_socket;
            pthread_create(&tid, NULL, handle_client, p_sock);
        } else {
            printf("[SERVER] Connessione rifiutata: server pieno.\n");
            close(new_socket);
        }
        pthread_mutex_unlock(&la_mia_partita.mutex);
    }
    return 0;
}