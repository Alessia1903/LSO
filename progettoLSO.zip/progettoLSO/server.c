#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Struttura per passare argomenti al thread (se serve)
typedef struct {
    int socket_fd;
} client_args;
typedef struct {
    // ... altri campi ...
    int turn; // 0 = tocca a Player A, 1 = tocca a Player B
    // ...
} Game;

// Funzione eseguita da ogni thread (un thread per ogni client)
void *handle_client(void *arg) {
    client_args *args = (client_args *)arg;
    int sock = args->socket_fd;
    free(args); // Liberiamo la memoria allocata nel main

    char buffer[BUFFER_SIZE];
    int bytes_read;

    printf("[THREAD] Nuovo giocatore connesso sul socket %d\n", sock);
    fflush(stdout);

    // Loop di ascolto messaggi dal client
   // ... dentro la funzione void *client_handler(void *arg) ...

while ((valread = recv(sock, buffer, 1024, 0)) > 0) {
    buffer[valread] = '\0'; // Terminatore stringa

    // -----------------------------------------------------------
    // SE IL COMANDO È "MOVE" (es: "MOVE 0 0")
    // -----------------------------------------------------------
    if (strncmp(buffer, "MOVE", 4) == 0) {
        int r, c;
        sscanf(buffer, "MOVE %d %d", &r, &c);

        // 1. Trova la partita (game) a cui partecipa questo client
        // (Assumiamo tu abbia una variabile 'game' che punta alla struct della partita)
        
        // 2. Blocca il Mutex (IMPORTANTE per l'esame!)
        pthread_mutex_lock(&game->mutex);

        // 3. Fai la mossa sulla scacchiera
        char symbol = (sock == game->player_a_sock) ? 'X' : 'O';
        game->board[r][c] = symbol;

        // -------------------------------------------------------
        // ECCO DOVE VA IL PEZZO DI CODICE "RESULT"
        // -------------------------------------------------------
        int result = check_winner(game->board);

        if (result == 1) { 
            // Vince X (Player A)
            send(game->player_a_sock, "VICTORY\n", 8, 0);
            send(game->player_b_sock, "DEFEAT\n", 7, 0);
            game->status = TERMINATED;
        } 
        else if (result == 2) { 
            // Vince O (Player B)
            send(game->player_a_sock, "DEFEAT\n", 7, 0);
            send(game->player_b_sock, "VICTORY\n", 8, 0);
            game->status = TERMINATED;
        } 
        else if (result == 3) { 
            // Pareggio
            send(game->player_a_sock, "DRAW\n", 5, 0);
            send(game->player_b_sock, "DRAW\n", 5, 0);
            game->status = TERMINATED;
        } 
        else {
            // 4. La partita continua: Notifica entrambi
            // Costruisci la stringa della board (es: "BOARD X_O__X___")
            char msg[32];
            sprintf(msg, "BOARD %c%c%c%c%c%c%c%c%c\n", 
                    game->board[0][0], game->board[0][1], game->board[0][2],
                    game->board[1][0], game->board[1][1], game->board[1][2],
                    game->board[2][0], game->board[2][1], game->board[2][2]);
            
            send(game->player_a_sock, msg, strlen(msg), 0);
            send(game->player_b_sock, msg, strlen(msg), 0);
        }

// --- CONTROLLO TURNO ---
int is_player_a = (sock == game->player_a_sock);
if ((game->turn == 0 && !is_player_a) || (game->turn == 1 && is_player_a)) {
    send(sock, "NOT_YOUR_TURN\n", 14, 0);
    pthread_mutex_unlock(&game->mutex);
    continue; // Salta il resto e aspetta il prossimo messaggio
}

// --- CONTROLLO CELLA VUOTA ---
if (game->board[r][c] != '_') {
    send(sock, "CELL_OCCUPIED\n", 14, 0);
    pthread_mutex_unlock(&game->mutex);
    continue;
}

// --- ESECUZIONE MOSSA ---
char symbol = is_player_a ? 'X' : 'O';
game->board[r][c] = symbol;

// --- CONTROLLO VINCITORE (il codice result di prima) ---
int result = check_winner(game->board);

if (result == 0) {
    // Se nessuno ha vinto, CAMBIA IL TURNO
    game->turn = (game->turn == 0) ? 1 : 0; 
    
    // Notifica la nuova board e di chi è il turno
    char msg[64];
    sprintf(msg, "BOARD %c%c%c%c%c%c%c%c%c NEXT %d\n", 
            game->board[0][0], game->board[0][1], game->board[0][2],
            game->board[1][0], game->board[1][1], game->board[1][2],
            game->board[2][0], game->board[2][1], game->board[2][2],
            game->turn);
    
    send(game->player_a_sock, msg, strlen(msg), 0);
    send(game->player_b_sock, msg, strlen(msg), 0);
} 
else {
    // ... qui va il codice delle vittorie/pareggio (result 1, 2, 3) ...
}

        // 5. Sblocca il Mutex
        pthread_mutex_unlock(&game->mutex);
        
    }
}

    if (bytes_read == 0) {
        printf("[THREAD] Client sul socket %d disconnesso.\n", sock);
        fflush(stdout);
    } else {
        perror("Errore nella recv");
    }

    close(sock);
    return NULL;
}

    void handle_shutdown(int sig) {
    printf("\n[SERVER] Ricevuto segnale di chiusura (%d). Pulizia in corso...\n", sig);
    fflush(stdout);
    // Qui potresti chiudere tutti i socket aperti
    exit(0);
}

// Codici di ritorno:
// 0 = La partita continua
// 1 = Ha vinto X
// 2 = Ha vinto O
// 3 = Pareggio (Griglia piena)

int check_winner(char board[3][3]) {
    // 1. Controllo Righe e Colonne
    for (int i = 0; i < 3; i++) {
        // Controllo Riga 'i'
        if (board[i][0] != '_' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
            return (board[i][0] == 'X') ? 1 : 2;
        }
        // Controllo Colonna 'i'
        if (board[0][i] != '_' && board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
            return (board[0][i] == 'X') ? 1 : 2;
        }
    }

    // 2. Controllo Diagonali
    if (board[1][1] != '_') {
        // Diagonale Principale (alto-sx -> basso-dx)
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2])
            return (board[1][1] == 'X') ? 1 : 2;
        
        // Diagonale Secondaria (alto-dx -> basso-sx)
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0])
            return (board[1][1] == 'X') ? 1 : 2;
    }

    // 3. Controllo Pareggio (c'è ancora spazio?)
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == '_') return 0; // Trovata cella vuota, si continua
        }
    }

    return 3; // Nessun vincitore e griglia piena: PAREGGIO
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    // 1. Creazione del socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket fallito");
        exit(EXIT_FAILURE);
    }

    // Opzione per riutilizzare la porta subito dopo la chiusura (utile per debug)
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("Setsockopt fallito");
        exit(EXIT_FAILURE);
    }

    // 2. Binding (Collegamento indirizzo/porta)
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY; // Ascolta su tutte le interfacce (Fondamentale per Docker!)
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind fallito");
        exit(EXIT_FAILURE);
    }

    // 3. Listening
    if (listen(server_fd, 10) < 0) { // 10 � la dimensione della coda di attesa
        perror("Listen fallito");
        exit(EXIT_FAILURE);
    }

    signal(SIGINT, handle_shutdown);

    printf("Server Tris avviato sulla porta %d...\n", PORT);
    fflush(stdout);

    // 4. Accept Loop (Accetta connessioni all'infinito)
    while (1) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept fallita");
            continue;
        }

        // Creiamo una struct per passare i dati al thread in modo sicuro
        client_args *args = malloc(sizeof(client_args));
        args->socket_fd = new_socket;

        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, handle_client, (void *)args) != 0) {
            perror("Impossibile creare il thread");
            free(args);
            close(new_socket);
        } else {
            // Detach del thread cos� pulisce le risorse da solo quando finisce
            pthread_detach(thread_id);
        }
    }

    

    return 0;
}
